# DenTag 1.1.0

Android向けのMP3・FLACタグ編集アプリ。音声の切り貼り・変換・再圧縮は行いません。

## 使い方

1. `DenTag-v1.1.0.apk` をスマホにダウンロードしてインストールします。
2. **曲を選ぶ**を押し、MP3またはFLACを開きます。
3. 曲名・アーティスト・アルバム名・トラック番号・発売年・ジャンルを編集します。
4. **写真を選ぶ**でジャケットを指定します。画像を消す場合は**画像を削除**を押します。
5. **音量補正（ReplayGain）**にdB値を入力します。不要ならそのままにします。
6. MP3本体の音量も変える場合は **MP3Gain** を開き、解析後に自動／手動調整を選んで **この設定で編集画面に戻る** を押します。不要ならそのままにします。
7. **保存する**を押し、次のどちらかを選びます。
   - **元の曲に上書き**：ファイル名を確認して**上書き保存**を押します。
   - **編集したコピーを保存**：保存先を選びます。既定名は `元の名前_edited.mp3` または `.flac` です。

保存した曲を音楽プレーヤーに読み込んでください。コピー保存では元の曲が残り、上書きでは選択した曲ファイルを更新します。編集項目を空欄にすると、そのタグが保存時に削除されます。

## 音量補正（1.0.2で追加）

曲ごとの `REPLAYGAIN_TRACK_GAIN` タグを手動編集します。音声データへの音量変更や音量の自動解析は行いません。

- マイナス値：小さく再生（例：`-3.0`）。
- プラス値：大きく再生（例：`+3.0`）。
- `0`：0 dBの補正タグを保存。
- 空欄・**解除**：曲単位の音量補正タグを削除。
- **-1 dB／+1 dB**：入力値を1 dBずつ調整。未設定では0 dBを起点にします。
- 入力範囲は-60〜+60 dB、保存値は小数点以下2桁。

MP3はID3のTXXX（ID3v2.2はTXX）、FLACはVorbis Commentに保存します。大文字・小文字のキーを読み込み、変更時は重複した同じ項目を1つに統一します。音量欄を変更しない場合は既存タグを保持します。

対応する音楽プレイヤー側でReplayGainを有効にし、曲単位（トラック）を選んでください。未対応プレイヤーや無効状態では反映されません。アルバム単位の音量補正タグ、ピーク値、その他のタグは保持します。解除するのは曲単位のGAINタグだけです。

## MP3Gain（1.1.0で追加）

ReplayGainタグとは別に、MP3 Layer IIIの `global_gain` を変更します。解析時にPCMへデコードしますが、保存時のデコード・再エンコードは行いません。ReplayGain非対応プレーヤーでも音量の変化が反映されます。FLACでは項目が無効になります。

- **現在の解析結果**：推定音量・推奨変更・適用予定・推定の適用後音量・クリッピング予測。
- **音量を自動調整**：標準89 dB。目標値は70〜100 dBで変更でき、次回にも保持します。曲単位のトラックゲインです。ピーク値とglobal gainの可変範囲に制限されるため、目標に届かない場合があります。
- **手動調整**：±ボタンで約1.5 dBずつ変更します。厳密な1段階は `5 × log10(2)` ≈ 1.50515 dBです。各フレームの音量値を丸めたりラップさせず、全て同じ段数だけ変更します。範囲外の変更はできません。
- クリッピングの可能性がある設定では、編集画面へ戻る前に **キャンセル／このまま適用** を表示します。予測は解析したPCMのピーク値に基づきます。浮動小数点PCMを出力できない端末では16 bit PCMによる推定であることを表示します。
- **この設定で編集画面に戻る** は変更の予約です。編集画面の **保存する** で上書き・コピー保存を選ぶと反映します。**変更予約を解除** で取り消せます。コピー保存では元ファイルは変わりません。
- **MP3Gainを元に戻す**：DenTagのUndo情報があり、解析した音声と一致する場合のみ使用できます。実行を予約した後、編集画面で保存します。繰り返した変更も、最初のMP3Gain適用前の音声へ戻ります。タグ編集とUndoは独立しており、後で編集したタイトル等は保持します。

Undo情報はID3のTXXX/TXX `DENTAG_MP3GAIN_UNDO` に保存します。形式は `1|累積変更段数|元の音声SHA-256|現在の音声SHA-256` です。別アプリが音声部分を書き換えた場合、破損した情報がある場合は安全のため処理を拒否します。タグが削除されるとUndoできません。他アプリが独自に保存した `MP3GAIN_UNDO` は保持しますが、そのUndo形式の復元は今回の対象外です。

MPEG-1 / 2 / 2.5 Layer III、モノラル・ステレオ、CBR・VBR、CRC付きフレームを扱います。音声フレーム中の有効なglobal gainと必要なCRCだけを変更し、変更後の全音声領域を検証します。ID3・ジャケット・ReplayGain・末尾のAPEは既存の保存処理で保持します。破損したフレーム、CRC不一致、途中で形式が変わるMP3、フリーフォーマットは処理を中止します。

今回の画面は1曲ずつ処理します。内部の `planTracks` / `prepareTrack` は複数曲のトラックゲインを計画・処理できる構造です。アルバム用のヒストグラム集計処理も分離していますが、複数選択画面・アルバムゲイン適用は未実装です。

表示する89 dB等はReplayGain方式の相対的な推定値です。スマートフォンの音量設定や、実際のスピーカーの音圧を測定するものではありません。

## 対応範囲

- Android 8.0以上。インターネット権限・広告・アカウント登録はありません。
- MP3：ID3v1の読み込み、ID3v2.2 / 2.3 / 2.4の読み書き。
- MP3のID3v2.2 / 2.3では発売年を4桁で入力します。
- FLAC：通常の `fLaC` 形式、Vorbis CommentとPICTUREブロック。
- 日本語・絵文字に対応。MP3では元のID3v2バージョンを維持します。
- 画像を変更しない場合、既存の複数画像を保持します。置き換える場合は1枚の表ジャケットに統一し、削除する場合は埋め込み画像をすべて取り除きます。
- 通常のJPEG・PNGを埋め込みます。大きな写真やその他の読み込める写真形式、回転情報付きの写真は、向きを直してJPEGに変換します。写真のみサイズ調整する場合があります。
- 編集項目以外の通常タグ（歌詞、コメント、アルバムアーティスト、ReplayGainのアルバム補正・ピーク値等）を保持します。同じ編集項目に複数の値がある場合は、画面で表示した1つの値に統一します。
- 古いID3v1は編集項目とコメントを読み込んでID3v2に移し、保存時にID3v1を取り除きます。古いID3v1の非標準日本語文字コードは対応対象外です。
- 圧縮・暗号化された編集対象タグ、破損タグ、32 MBを超えるメタデータ、Ogg内のFLACなどは処理対象外です。ID3の任意のCRC拡張ヘッダーは再出力しません。通常の曲ファイルを対象とした初版です。

## 保存と検証

元の曲をアプリの一時領域にコピーして編集します。通常のタグ編集では音声部分のSHA-256が同じことを確認します。MP3Gainでは別の一時ファイルを処理し、global gain・CRC以外の全バイトが同じことを確認してからタグを保存します。書き出したタグ・ジャケットを再読込して検証した後に保存先に出力し、保存先の全ファイルのSHA-256も確認します。MP3Gainでは曲のサイズの約5倍分（通常のタグ編集では約4倍分）の空き容量を確保してください（大きな画像を追加する場合はさらに必要です）。

上書きには選択したファイルへの書き込み許可が必要です。書き込み非対応の保存場所ではコピー保存を案内します。選んだ元ファイルのURIとアクセス許可を保持し、そのファイルだけを更新します。編集開始後に別アプリで元の曲が変更されていた場合は、上書きを中止します。

上書き前に元ファイルをアプリの永続領域に退避・検証します。保存失敗時には元データの書き戻しと検証を試みます。復元も失敗した場合やアプリ終了で上書きが中断した場合は、次回起動時に**元データを保存**を案内し、元の曲を別ファイルとして取り出せます。退避ファイルは取り出しが完了するまで保持し、新しい上書きを停止します。端末や保存先の故障・アプリのデータ消去まで保証する仕組みではありません。

保存先は読み取りにも対応していることが必要です。通常の端末内フォルダを推奨します。コピー保存後の確認に失敗した場合は成功とせず、作成したコピーの削除を試みます。上書き元のファイルを削除する処理はありません。

## 1.1.0の変更

- MP3Gainの解析・89 dBへの自動調整・手動調整・クリッピング警告。
- 上書き／コピー保存と永続Undo情報の連携。
- global gain・CRC以外の音声データが変わっていないことを検証。
- ReplayGain、MP3／FLACタグ、画像の既存機能を維持。

## 1.0.2の変更

- 曲単位の音量補正（ReplayGain）の表示・手動編集・削除。
- 音量補正を1 dBずつ調整するボタン。
- MP3・FLACの音量タグの読み直し検証。

## 1.0.1の変更

- 保存時に上書き・コピー保存を選択。
- 上書き前のファイル名確認、書き込み許可の確認。
- 元データの退避、保存先の照合、失敗時の復元・取り出し。
- 上書き成功後も続けて同じ曲を編集可能。
- バージョン番号を更新し、初版と同じ署名鍵を維持。

## ビルド

Java 8以上のコンパイラとAndroid SDKを用意します（platform android-35、build-tools 35.0.0）。

```bash
ANDROID_SDK_ROOT=/absolute/path/to/android-sdk bash build-apk.sh
```

`javac` がない環境ではECJでビルドできます。

```bash
ANDROID_SDK_ROOT=/absolute/path/to/android-sdk ECJ_JAR=/absolute/path/to/ecj.jar bash build-apk.sh
```

出力は `dist/DenTag-v1.1.0.apk` です。公開用ソースには配布APKの署名鍵を含めていません。ビルド時にローカルの署名鍵を生成するため、自己ビルドしたAPKは配布版へ上書きインストールできません。

## 検証結果

`tests/test_engine.py` で24ケースを検証しました。Mutagenによるタグ・画像の相互運用確認、FFmpegによる保存前後のデコード音声の一致確認、タグなしMP3、ID3v1・v2.2・v2.3・v2.4、unsynchronisation、拡張ヘッダー、フッター、画像保持・追加置換・削除、空欄削除、歌詞等の保持、不正ファイルの拒否を含みます。

`tests/SaveHarness.java` では実際の保存処理に障害を注入し、正常上書き・連続編集・途中書き込み失敗・開く際の切り詰め後の失敗・照合失敗・復元失敗・退避保持・外部変更・コピー保存など13ケースを検証しました。

`tests/test_gain.py` で音量補正の39ケースも検証しました。ID3v2.2・2.3・2.4、FLAC、既存タグの保持・正負の補正・0 dB・削除・重複の統一・入力検証を含みます。Mutagenによる読み取りと、FFmpegのデコード音声一致を確認しました。既存機能の合計76ケースは1.1.0でも再実行し、全て通っています。

`tests/test_mp3gain.py` の156ケースを追加しました。12種類のサンプルレートで元のC版ReplayGain解析と比較し、実際のMP3・LAME生成のCRC付きMP3で再生音量の倍率とUndoの完全一致を確認しています。MPEG全バージョンの音量値・CRC以外のビット保持、タグ・画像・ReplayGain保持、89 dB等への自動調整、累積Undo、外部変更や破損データの拒否も確認しました。全体は232ケースです。

APKのビルドとv2 / v3署名検証、既存版との署名一致の確認は完了しています。Android実機・エミュレーターでの画面操作、MediaCodecによる実機の音量解析、実際のSAFプロバイダー経由の保存はこの環境では未確認です。これらの端末上の完了条件は実機での確認が必要です。

仕様参照：
- https://id3.org/id3v2.3.0
- https://id3.org/id3v2.4.0-structure
- https://www.xiph.org/flac/documentation_format_overview.html
- https://developer.android.com/training/data-storage/shared/documents
- https://picard-docs.musicbrainz.org/en/latest/appendices/tag_mapping.html
- https://wiki.xiph.org/VorbisComment

テスト用のPython依存：`mutagen`、`Pillow`、`numpy`。`ffmpeg`、`ffprobe`、`gcc`、`libmp3lame`も使用します。

```bash
mkdir -p build/test-classes
javac -encoding UTF-8 -d build/test-classes src/jp/dengaku/dentag/TagEngine.java src/jp/dengaku/dentag/SaveEngine.java src/jp/dengaku/dentag/Mp3GainEngine.java src/jp/dengaku/dentag/ReplayGainAnalysis.java tests/EngineHarness.java tests/SaveHarness.java tests/GainHarness.java tests/Mp3GainHarness.java
java -cp build/test-classes jp.dengaku.dentag.SaveHarness
python3 tests/test_engine.py
python3 tests/test_gain.py
gcc -std=c99 -O2 -I third_party/replaygain tests/replaygain_reference.c third_party/replaygain/gain_analysis.c -lm -o build/replaygain-reference
python3 tests/test_mp3gain.py
```

## 音量解析ライブラリとライセンス

`ReplayGainAnalysis.java` はMP3Gainの `gain_analysis.c` をJavaに移植したものです。David Robinson / Glen Sawyer、改良 Frank Klemm / Marcel Mueller。GNU LGPL 2.1以降を適用します。元ソースと全文ライセンスは `third_party/replaygain/` に、Java移植のソースは `src/` に含めています。APKのMP3Gain画面からもライセンスを読めます。

このライブラリの変更・再リンクに必要なアプリソースとビルド手順を提供します。LGPLが認めるライブラリ改変、改変版への再リンクおよびそのデバッグのためのリバースエンジニアリングを制限しません。

参照： https://github.com/strohel/mp3gain 、 https://developer.android.com/reference/android/media/MediaCodec 、 https://android.googlesource.com/platform/external/opencore/+/refs/heads/master/codecs_v2/audio/mp3/dec/src/pvmp3_get_side_info.cpp
