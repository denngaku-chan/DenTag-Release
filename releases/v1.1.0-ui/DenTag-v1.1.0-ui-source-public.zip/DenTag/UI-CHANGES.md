# DenTag v1.1.0 UI update

- Removed the upper-right song picker button. The song card now opens the existing picker, both before and after selecting a song.
- The existing unsaved-change confirmation and busy-state guards are preserved.
- Grouped MP3Gain Undo and reservation-clear controls, added a compact help card, and moved cancel/return actions into a fixed bottom area.
- Kept the LGPL library license accessible using a quieter text-style action.
- Only MainActivity.java and Mp3GainActivity.java were changed. Audio processing and save engines are unchanged.

Validation: all 232 existing processing tests passed; the APK build, alignment, v2/v3 signing, and the distribution signing certificate passed. Android device rendering and tap interactions have not been run in this environment.

The APK uses the existing v1.1.0 version metadata and the user's retained distribution key. This public source archive includes no private signing material. The original build instructions produce an APK signed with a local development key; the cloud environment signing wrapper signs the delivered APK using the separately retained distribution key.
