package jp.dengaku.dentag;
import java.io.*;
import java.util.*;
public final class Mp3GainHarness {
    public static void main(String[] args) throws Exception {
        if(args[0].equals("clip")){System.out.println(Mp3GainEngine.clipping(Double.parseDouble(args[1]),Integer.parseInt(args[2])));return;}
        if(args[0].equals("batch")){ArrayList<Mp3GainEngine.TrackMeasurement> tracks=new ArrayList<>();for(int i=1;i<args.length;i++)tracks.add(new Mp3GainEngine.TrackMeasurement(new File(args[i]),Mp3GainEngine.inspect(new File(args[i])),i==1?3:-6,.2));List<Mp3GainEngine.TrackPlan> plans=Mp3GainEngine.planTracks(tracks,89);if(plans.size()!=tracks.size()||plans.get(0).steps!=2||plans.get(1).steps!=-4)throw new AssertionError();System.out.println(plans.size());return;}
        if(args[0].equals("analyze")){ReplayGainAnalysis a=new ReplayGainAnalysis(Integer.parseInt(args[1]));try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(args[2])))){while(in.available()>0)a.add(in.readDouble(),in.readDouble());}System.out.printf(Locale.ROOT,"%.8f %.8f %d%n",a.gain(),a.peak(),a.samples());return;}
        if(args[0].equals("recommend")){Mp3GainEngine.Info info=Mp3GainEngine.inspect(new File(args[1]));int steps=Mp3GainEngine.recommendedSteps(Double.parseDouble(args[2]),Double.parseDouble(args[3]),info,Double.parseDouble(args[4]));System.out.println(steps+" "+Mp3GainEngine.clipping(Double.parseDouble(args[4]),steps));return;}
        if(args[0].equals("inspect")){File f=new File(args[1]);Mp3GainEngine.Info i=Mp3GainEngine.inspect(f);System.out.println(i.sampleRate+" "+i.channels+" "+i.frames+" "+i.activeSlots+" "+i.minimumSteps()+" "+i.maximumSteps()+" "+i.audioHash);return;}
        File src=new File(args[1]),dst=new File(args[2]);File temp=File.createTempFile("gain-test-",".mp3");
        try{Mp3GainEngine.Prepared p=Mp3GainEngine.prepare(src,temp,Integer.parseInt(args[3]),args[0].equals("undo"));TagEngine.Song s=TagEngine.read(temp);String[] values=s.values.clone();if(args.length>4)values[0]=args[4];TagEngine.write(temp,dst,s,values,s.picture,false,s.trackGain,false,p.undo,true);Mp3GainEngine.verifyTransform(src,dst,p.appliedSteps);System.out.println(p.appliedSteps+" "+TagEngine.read(dst).mp3GainUndo);}
        finally{temp.delete();}
    }
}
