"""Real MP3/FLAC interoperability tests with Mutagen and FFmpeg.
Run after compiling EngineHarness + TagEngine into build/test-classes.
"""
import hashlib, json, pathlib, struct, subprocess, tempfile
from PIL import Image
from mutagen.id3 import ID3, TIT2, TPE1, TALB, TRCK, TYER, TCON, APIC, TXXX, COMM, USLT
from mutagen.flac import FLAC, Picture
from mutagen.mp3 import MP3

ROOT = pathlib.Path(__file__).resolve().parents[1]
CP = ROOT / 'build/test-classes'
EXPECTED = ['日本語の曲名 🎵','でんがく','テスト・アルバム','3/12','2026','J-Pop']
work = pathlib.Path(tempfile.mkdtemp(prefix='dentag-test-'))
checks = []

def run(*args, **kw):
    return subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kw).stdout
def engine(src, dst=None, art=None, clear=False):
    args = ['java','-cp',str(CP),'jp.dengaku.dentag.EngineHarness',str(src)]
    if dst: args.append(str(dst))
    if art: args.append(str(art))
    if clear: args.append('clear')
    return run(*args).decode()
def pcm(f):
    return hashlib.sha256(run('ffmpeg','-v','error','-i',str(f),'-map','0:a:0','-f','s16le','-')).hexdigest()
def metadata(f):
    return json.loads(run('ffprobe','-v','error','-show_format','-show_streams','-of','json',str(f)))
def expect_tags(f,flac=False,empty=False):
    tags=FLAC(f) if flac else ID3(f)
    names=['title','artist','album','tracknumber','date','genre'] if flac else ['TIT2','TPE1','TALB','TRCK','TDRC','TCON']
    for name,value in zip(names,EXPECTED):
        if empty: assert name not in tags, (name,tags)
        elif flac: assert tags[name][0]==value
        else: assert str(tags[name])==value,(name,str(tags.get(name)))
def check(name,src,dst,flac=False,cover=None,removed=False,empty=False):
    expect_tags(dst,flac,empty)
    assert pcm(src)==pcm(dst),name+' decoded audio changed'
    report=metadata(dst)
    assert report['streams'][0]['codec_type']=='audio'
    art=FLAC(dst).pictures if flac else list(ID3(dst).getall('APIC'))
    if removed: assert len(art)==0
    elif cover is not None: assert any(p.data==cover for p in art)
    checks.append(name)

def sync(v): return bytes((v>>21&127,v>>14&127,v>>7&127,v&127))
def frame(ident,data,v=3,flags=0):
    if v==2:return ident.encode()+len(data).to_bytes(3,'big')+data
    size=sync(len(data)) if v==4 else len(data).to_bytes(4,'big')
    return ident.encode()+size+flags.to_bytes(2,'big')+data
def tag(body,v=3,flags=0):return b'ID3'+bytes([v,0,flags])+sync(len(body))+body

def main():
    image=work/'art.png';Image.new('RGB',(64,64),(53,92,74)).save(image)
    art=image.read_bytes()
    mp3=work/'base.mp3';flac=work/'base.flac'
    for f in (mp3,flac):run('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=0.2','-y',str(f))
    audio=mp3.read_bytes();old_size=10+int.from_bytes(b'\0','big')
    if audio.startswith(b'ID3'):
        n=0
        for b in audio[6:10]:n=n*128+b
        audio=audio[10+n:]
    for v in (3,4):
        src=work/f'v{v}.mp3';src.write_bytes(audio)
        t=ID3();t.add(TIT2(encoding=1,text=['元の曲名']));t.add(TPE1(encoding=1,text=['元の歌手']));t.add(TXXX(encoding=3,desc='REPLAYGAIN_TRACK_GAIN',text=['-3 dB']))
        t.add(COMM(encoding=1,lang='jpn',desc='',text=['コメントを残す']));t.add(USLT(encoding=1,lang='jpn',desc='',text='歌詞も残す'))
        for kind in (3,4):t.add(APIC(encoding=0,mime='image/png',type=kind,desc=str(kind),data=art))
        t.save(src,v2_version=v)
        for action in ('keep','replace','remove','clear'):
            dst=work/f'v{v}-{action}.mp3'
            engine(src,dst,image if action=='replace' else 'remove' if action in ('remove','clear') else None,action=='clear')
            check(f'MP3 ID3v2.{v} {action}',src,dst,cover=art if action in ('keep','replace') else None,removed=action in ('remove','clear'),empty=action=='clear')
            tags=ID3(dst);assert str(tags.getall('TXXX')[0])=='-3 dB';assert tags.getall('COMM')[0].text==['コメントを残す'];assert tags.getall('USLT')[0].text=='歌詞も残す'
            assert len(tags.getall('APIC'))==(2 if action=='keep' else 1 if action=='replace' else 0)
    # Tagless MP3 and legacy ID3v1 import.
    for legacy in (False,True):
        src=work/f'legacy-{legacy}.mp3';tail=b''
        if legacy:
            tail=b'TAG'+b'Old song'.ljust(30,b'\0')+b'Old artist'.ljust(30,b'\0')+b'Old album'.ljust(30,b'\0')+b'1999'+b'legacy comment'.ljust(28,b'\0')+bytes([0,1,17])
            assert len(tail)==128
        src.write_bytes(audio+tail);dst=work/f'legacy-{legacy}-out.mp3';engine(src,dst,image);check(f'MP3 tagless/legacy={legacy}',src,dst,cover=art)
        if legacy:assert ID3(dst).getall('COMM')[0].text==['legacy comment']
    # v2.2, tag-level unsynchronisation v2.3, frame-level unsynchronisation v2.4, extended header.
    for case,v in [('v22',2),('unsync3',3),('unsync4',4),('extended3',3),('footer4',4)]:
        body=frame('TT2' if v==2 else 'TIT2',b'\x01'+ '旧タイトル'.encode('utf-16'),v)
        flags=0
        if case=='v22':body+=frame('PIC',b'\0PNG\x03\0'+art,2)
        elif case=='unsync3':
            body+=frame('PRIV',b'owner\0\xff\xe0\xff\x00');body=body.replace(b'\xff',b'\xff\x00');flags=128
        elif case=='unsync4':body+=frame('PRIV',b'owner\0\xff\x00\xe0',4,2)
        elif case=='extended3':body=b'\0\0\0\x06'+b'\0'*6+body;flags=64
        elif case=='footer4':flags=16
        src=work/f'{case}.mp3';src.write_bytes(tag(body,v,flags)+(b'3DI'+bytes([4,0,16])+sync(len(body)) if case=='footer4' else b'')+audio)
        dst=work/f'{case}-out.mp3';engine(src,dst,image);check(case,src,dst,cover=art)
        if case.startswith('unsync'):assert ID3(dst).getall('PRIV')[0].data==(b'\xff\xe0\xff\0' if v==3 else b'\xff\xe0')
    f=FLAC(flac);f['title']='元のタイトル';f['replaygain_track_gain']='-2 dB';f['lyrics']='元の歌詞';
    for kind in (3,4):
        p=Picture();p.type=kind;p.mime='image/png';p.width=p.height=64;p.depth=24;p.data=art;f.add_picture(p)
    f.save()
    for action in ('keep','replace','remove','clear'):
        dst=work/f'flac-{action}.flac';engine(flac,dst,image if action=='replace' else 'remove' if action in ('remove','clear') else None,action=='clear')
        check('FLAC '+action,flac,dst,True,cover=art if action in ('keep','replace') else None,removed=action in ('remove','clear'),empty=action=='clear')
        f=FLAC(dst);assert f['replaygain_track_gain']==['-2 dB'];assert f['lyrics']==['元の歌詞'];assert len(f.pictures)==(2 if action=='keep' else 1 if action=='replace' else 0)
    # Reject truncated and unsupported tags without touching the source.
    for case,data in [('truncated',tag(b'xxxx',3)+audio),('bad-size',b'ID3\x03\0\0'+sync(30000000)+audio),('not-audio',b'hello world'),('bad-flac',b'fLaC\x80\x00\x00\x22x'),('encrypted',tag(frame('TIT2',b'\x00secret',3,0x40))+audio)]:
        src=work/f'bad-{case}.bin';src.write_bytes(data)
        try:engine(src,work/f'bad-{case}-out.bin')
        except subprocess.CalledProcessError:pass
        else:raise AssertionError('malformed file accepted: '+case)
        assert src.read_bytes()==data
        checks.append('reject '+case)
    result={'passed':len(checks),'checks':checks,'fixture_dir':str(work),'verification':'Mutagen reads all edited fields and art; FFmpeg decoded PCM matches originals; Java verifies raw audio SHA-256 on each save.'}
    (ROOT/'test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
