package jp.dengaku.dentag;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Injects document-provider failures into the actual save path. */
public final class SaveHarness {
    static int passed;
    static final byte[] ORIGINAL=new byte[150123], EDITED=new byte[73001];
    static {new Random(1).nextBytes(ORIGINAL);new Random(2).nextBytes(EDITED);}
    static final class Target implements SaveEngine.Target {
        final File file;int reads,writes,failWrite,corruptRead,failRead,failOpen;boolean allWritesFail;
        Target(File f){file=f;}
        public InputStream openRead() throws IOException {
            reads++;
            if(reads==failRead)throw new IOException("read failure");
            if(reads==corruptRead)return new ByteArrayInputStream(new byte[]{1,2,3});
            return new FileInputStream(file);
        }
        public OutputStream openWrite() throws IOException {
            writes++;final FileOutputStream out=new FileOutputStream(file);
            if(writes==failOpen){out.close();throw new IOException("truncated before open failure");}
            if(allWritesFail||writes==failWrite)return new FilterOutputStream(out){
                public void write(byte[] b,int off,int len) throws IOException {out.write(b,off,Math.min(23,len));throw new IOException("partial write");}
            };
            return out;
        }
    }
    static void require(boolean b){if(!b)throw new AssertionError();}
    static void bytes(File f,byte[] b) throws Exception {require(Arrays.equals(Files.readAllBytes(f.toPath()),b));}
    static void test(String mode) throws Exception {
        File dir=Files.createTempDirectory("dentag-save-").toFile();
        File original=new File(dir,"original"),edited=new File(dir,"edited"),document=new File(dir,"document"),backup=new File(dir,"backup"),check=new File(dir,"check");
        Files.write(original.toPath(),ORIGINAL);Files.write(edited.toPath(),EDITED);Files.write(document.toPath(),ORIGINAL);
        Target target=new Target(document);
        boolean expectedFailure=true,expectRecovery=false;
        if(mode.equals("success"))expectedFailure=false;
        if(mode.equals("partial"))target.failWrite=1;
        if(mode.equals("verify-corrupt"))target.corruptRead=2;
        if(mode.equals("verify-read-error"))target.failRead=2;
        if(mode.equals("truncate-open-error"))target.failOpen=1;
        if(mode.equals("rollback-failed")){target.allWritesFail=true;expectRecovery=true;}
        if(mode.equals("rollback-verify-failed")){target.failWrite=1;target.failRead=2;expectRecovery=true;}
        if(mode.equals("stale"))Files.write(document.toPath(),new byte[]{9,9});
        if(mode.equals("already-backed-up"))Files.write(backup.toPath(),new byte[]{8,8});
        if(mode.equals("backup-unavailable"))backup=new File(new File(dir,"missing"),"backup");
        if(mode.equals("preflight-read-error"))target.failRead=1;
        if(mode.equals("edited-missing"))edited.delete();
        IOException failure=null;
        try{SaveEngine.overwrite(original,edited,target,backup,check);}catch(IOException e){failure=e;}
        require((failure!=null)==expectedFailure);
        require((failure instanceof SaveEngine.RecoveryRequired)==expectRecovery);
        bytes(original,ORIGINAL);
        if(expectRecovery){bytes(backup,ORIGINAL);}
        else if(mode.equals("already-backed-up")){bytes(backup,new byte[]{8,8});bytes(document,ORIGINAL);require(target.writes==0);}
        else if(mode.equals("stale")){bytes(document,new byte[]{9,9});require(target.writes==0);require(!backup.exists());}
        else{bytes(document,mode.equals("success")?EDITED:ORIGINAL);require(!backup.exists());}
        if(!expectedFailure){
            // A second edit uses the newly committed file as the new baseline.
            Files.write(original.toPath(),EDITED);Files.write(edited.toPath(),ORIGINAL);
            SaveEngine.overwrite(original,edited,target,backup,check);bytes(document,ORIGINAL);
        }
        System.out.println("PASS "+mode);passed++;
    }
    public static void main(String[] args) throws Exception {
        for(String mode:new String[]{"success","partial","verify-corrupt","verify-read-error","truncate-open-error","rollback-failed","rollback-verify-failed","stale","already-backed-up","backup-unavailable","preflight-read-error","edited-missing"})test(mode);
        File dir=Files.createTempDirectory("dentag-copy-").toFile(),src=new File(dir,"src"),dst=new File(dir,"dst"),check=new File(dir,"check");
        Files.write(src.toPath(),ORIGINAL);Target target=new Target(dst);SaveEngine.copyVerified(src,target,check);bytes(src,ORIGINAL);bytes(dst,ORIGINAL);passed++;
        System.out.println("PASS copy keeps original; total="+passed);
    }
}
