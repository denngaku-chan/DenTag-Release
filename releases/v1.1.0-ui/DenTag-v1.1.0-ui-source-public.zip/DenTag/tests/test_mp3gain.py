"""Independent bitstream/PCM/metadata/Undo checks and original C ReplayGain comparison."""
import ctypes,ctypes.util,hashlib,json,pathlib,struct,subprocess,tempfile
import numpy as np
from mutagen.id3 import ID3,TXXX,TIT2,APIC
ROOT=pathlib.Path(__file__).resolve().parents[1];CP=ROOT/'build/test-classes'
work=pathlib.Path(tempfile.mkdtemp(prefix='dentag-mp3gain-'));checks=[]
def run(*args):return subprocess.run([str(a) for a in args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def java(*args):return run('java','-cp',CP,'jp.dengaku.dentag.Mp3GainHarness',*args).decode().strip()
def check(name,condition=True):
    assert condition,name;checks.append(name)
def rejects(name,*args):
    try:java(*args)
    except subprocess.CalledProcessError:check(name)
    else:raise AssertionError('Accepted '+name)
def pcm(path):return np.frombuffer(run('ffmpeg','-v','error','-i',path,'-map','0:a:0','-f','f32le','-'),dtype='<f4').copy()
def analyze(values,rate,channels):
    values=values.reshape(-1,channels).astype(np.float64)
    if channels==1:values=np.repeat(values,2,axis=1)
    path=work/'pcm.double';path.write_bytes(values.astype('>f8').tobytes())
    return float(java('analyze',rate,path).split()[0])
def getbits(b,start,n):return (int.from_bytes(b,'big')>>(len(b)*8-start-n))&((1<<n)-1)
def putbits(b,start,n,v):
    value=int.from_bytes(b,'big');shift=len(b)*8-start-n;value=(value&~(((1<<n)-1)<<shift))|(v<<shift);return value.to_bytes(len(b),'big')
def crc(frame,side_start,side_size):
    c=65535
    for b in frame[2:4]+frame[side_start:side_start+side_size]:
        for bit in range(7,-1,-1):
            flag=(c>>15)^((b>>bit)&1);c=c<<1&65535
            if flag&1:c^=0x8005
    return c

def audio(path):
    b=path.read_bytes()
    if b[:3]==b'ID3':
        size=0
        for n in b[6:10]:size=size*128+n
        b=b[10+size+(10 if b[3]==4 and b[5]&16 else 0):]
    if b[-128:-125]==b'TAG':b=b[:-128]
    return b

def bit_check(before,after,steps):
    a=audio(before);b=audio(after);assert len(a)==len(b);pos=0;frames=0
    while pos+4<=len(a) and a[pos:pos+2]!=b'AP':
        h=a[pos:pos+4];version=(h[1]>>3)&3;channels=1 if h[3]>>6==3 else 2;rate=[44100,48000,32000][h[2]>>2&3]//(1 if version==3 else 2 if version==2 else 4)
        bitrates=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320] if version==3 else [0,8,16,24,32,40,48,56,64,80,96,112,128,144,160]
        length=(144000 if version==3 else 72000)*bitrates[h[2]>>4]//rate+(h[2]>>1&1);assert pos+length<=len(a)
        protected=not(h[1]&1);start=6 if protected else 4;side_size=(17 if channels==1 else 32) if version==3 else (9 if channels==1 else 17)
        lead=9+(5 if channels==1 else 3)+4*channels if version==3 else 8+(1 if channels==1 else 2);stride=59 if version==3 else 63
        expected=a[pos:pos+length]
        for i in range((2 if version==3 else 1)*channels):
            bit=start*8+lead+i*stride
            if getbits(expected,bit,12):expected=putbits(expected,bit+21,8,getbits(expected,bit+21,8)+steps)
        if protected:expected=expected[:4]+crc(expected,start,side_size).to_bytes(2,'big')+expected[6:]
        assert expected==b[pos:pos+length],(pos,steps);pos+=length;frames+=1
    assert a[pos:]==b[pos:];assert frames>0

# Reference agreement at every filter sample rate, over mixed-tone and transient inputs.
for rate in [8000,11025,12000,16000,22050,24000,32000,44100,48000,64000,88200,96000]:
    time=np.arange(rate*2)/rate;rng=np.random.default_rng(rate)
    for case in range(2):
        left=(np.sin(2*np.pi*997*time)*.03+np.sin(2*np.pi*113*time)*.1+rng.normal(0,.004,len(time)))*(1 if case==0 else (.2+.8*(time>.7)))
        right=left*.37+np.sin(2*np.pi*1999*time)*.02;path=work/'reference.double';path.write_bytes(np.stack([left,right],axis=1).astype('>f8').tobytes())
        j=float(java('analyze',rate,path).split()[0]);c=float(run(ROOT/'build/replaygain-reference',rate,path));check(f'C ReplayGain agreement {rate}Hz case{case}',abs(j-c)<=.011)
short=work/'short.double';short.write_bytes(np.zeros((10,2),dtype='>f8').tobytes());rejects('analysis rejects insufficient samples','analyze',44100,short)

fixtures=[]
for rate,channels,quality in [(44100,1,'CBR'),(44100,2,'VBR'),(48000,2,'CBR'),(32000,2,'VBR'),(24000,1,'CBR'),(22050,2,'VBR'),(16000,2,'CBR'),(12000,1,'CBR'),(11025,2,'VBR'),(8000,1,'CBR')]:
    src=work/f'{rate}-{channels}-{quality}.mp3'
    encoding=['-q:a','3'] if quality=='VBR' else ['-b:a','128k' if rate>=32000 else '64k']
    run('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=997:duration=0.7','-ar',rate,'-ac',channels,'-codec:a','libmp3lame',*encoding,'-y',src)
    t=ID3(src);t.add(TIT2(encoding=1,text=['元の曲 🎵']));t.add(APIC(encoding=1,mime='image/png',type=3,desc='cover',data=b'unchanged-image-bytes'))
    for key,value in [('REPLAYGAIN_TRACK_GAIN','-4.0 dB'),('REPLAYGAIN_ALBUM_GAIN','-3.0 dB'),('REPLAYGAIN_TRACK_PEAK','0.91'),('MP3GAIN_UNDO','external-undo-kept'),('NOTE','日本語保持')]:t.add(TXXX(encoding=1,desc=key,text=[value]))
    t.save(src,v2_version=3 if channels==1 else 4);original=src.read_bytes();baseline=pcm(src);fixtures.append(src)
    info=java('inspect',src).split();check(f'inspect {src.stem}',int(info[0])==rate and int(info[1])==channels)
    for steps in [-4,4]:
        out=work/f'{src.stem}-{steps}.mp3';java('apply',src,out,steps);bit_check(src,out,steps);after=pcm(out);scale=2**(steps/4)
        check(f'PCM scales {src.stem} {steps}',len(after)==len(baseline) and np.linalg.norm(after-scale*baseline)/np.linalg.norm(baseline)<2e-5)
        tags=ID3(out);check(f'metadata and cover kept {src.stem} {steps}',str(tags['TIT2'])=='元の曲 🎵' and tags.getall('APIC')[0].data==b'unchanged-image-bytes' and all(list(tags['TXXX:'+key].text)==[value] for key,value in [('REPLAYGAIN_TRACK_GAIN','-4.0 dB'),('REPLAYGAIN_ALBUM_GAIN','-3.0 dB'),('REPLAYGAIN_TRACK_PEAK','0.91'),('MP3GAIN_UNDO','external-undo-kept'),('NOTE','日本語保持')]))
        undone=work/f'{src.stem}-{steps}-undone.mp3';java('undo',out,undone,0);check(f'reopened Undo exact audio {src.stem} {steps}',audio(src)==audio(undone) and np.array_equal(pcm(undone),baseline) and 'TXXX:DENTAG_MP3GAIN_UNDO' not in ID3(undone))
    check(f'original untouched {src.stem}',original==src.read_bytes())

src=fixtures[1];base=pcm(src);rate=44100;gain=analyze(base,rate,2);peak=float(np.max(np.abs(base)))
for target in [89,85,92]:
    steps=int(java('recommend',src,gain,target,peak).split()[0]);out=work/f'auto-{target}.mp3';java('apply',src,out,steps);new_gain=analyze(pcm(out),rate,2)
    check(f'automatic target {target}',abs((89-new_gain)-target)<=.77 and np.max(np.abs(pcm(out)))<1)
check('clipping detection positive',java('recommend',src,20,89,.95).split()[1]=='false')
check('clipping headroom clamp',int(java('recommend',src,20,89,.95).split()[0])<=0)
rejects('target out of range','recommend',src,gain,101,peak)
rejects('target NaN','recommend',src,gain,'NaN',peak)
info=java('inspect',src).split();rejects('gain range prevents wrap','apply',src,work/'range.mp3',int(info[5])+1)
rejects('missing Undo','undo',src,work/'missing-undo.mp3',0)
first=work/'first.mp3';second=work/'second.mp3';final=work/'cumulative-undo.mp3'
java('apply',src,first,-2);java('apply',first,second,1,'新しい曲名');java('undo',second,final,0)
check('cumulative Undo and edited metadata',audio(final)==audio(src) and str(ID3(final)['TIT2'])=='新しい曲名')
zero=work/'zero.mp3';java('apply',src,zero,0);check('zero gain has no new Undo',audio(zero)==audio(src) and 'TXXX:DENTAG_MP3GAIN_UNDO' not in ID3(zero))
roundtrip=work/'roundtrip.mp3';java('apply',first,roundtrip,2);check('opposite steps clear Undo',audio(src)==audio(roundtrip) and 'TXXX:DENTAG_MP3GAIN_UNDO' not in ID3(roundtrip))
# Tag-only edit retains hash-bound Undo; later volume change accumulates correctly.
retag=work/'retag.mp3';run('java','-cp',CP,'jp.dengaku.dentag.GainHarness',first,retag,'+2');java('undo',retag,work/'retag-undo.mp3',0)
check('ReplayGain edit retains usable Undo',audio(src)==audio(work/'retag-undo.mp3') and list(ID3(work/'retag-undo.mp3')['TXXX:REPLAYGAIN_TRACK_GAIN'].text)==['+2.00 dB'])
# Audio edited externally after MP3Gain must be rejected without changing source/destination.
tampered=work/'tampered.mp3';tampered.write_bytes(first.read_bytes());raw=tampered.read_bytes();start=len(raw)-len(audio(tampered));raw=bytearray(raw);raw[start+100]^=1;tampered.write_bytes(raw);snapshot=tampered.read_bytes()
rejects('externally changed audio rejects Undo','undo',tampered,work/'bad-undo.mp3',0);rejects('externally changed audio rejects another gain','apply',tampered,work/'bad-gain.mp3',1)
check('failed processing preserves source',tampered.read_bytes()==snapshot and not (work/'bad-undo.mp3').exists() and not (work/'bad-gain.mp3').exists())
bad_undo=work/'bad-info.mp3';bad_undo.write_bytes(src.read_bytes());t=ID3(bad_undo);t.add(TXXX(encoding=3,desc='DENTAG_MP3GAIN_UNDO',text=['broken']));t.save();rejects('malformed Undo rejects processing','apply',bad_undo,work/'bad-info-out.mp3',1)

# Actual LAME CRC-protected encoded audio, independent of the synthetic layout fixtures.
lib=ctypes.CDLL(ctypes.util.find_library('mp3lame'));lib.lame_init.restype=ctypes.c_void_p
for method in ['lame_set_in_samplerate','lame_set_out_samplerate','lame_set_num_channels','lame_set_mode','lame_set_brate','lame_set_error_protection','lame_set_bWriteVbrTag']:
    getattr(lib,method).argtypes=[ctypes.c_void_p,ctypes.c_int]
lib.lame_init_params.argtypes=[ctypes.c_void_p];lib.lame_close.argtypes=[ctypes.c_void_p]
lib.lame_encode_buffer.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_short),ctypes.POINTER(ctypes.c_short),ctypes.c_int,ctypes.POINTER(ctypes.c_ubyte),ctypes.c_int]
lib.lame_encode_flush.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ubyte),ctypes.c_int]
for rate,channels in [(44100,1),(44100,2),(22050,1),(22050,2)]:
    handle=lib.lame_init();lib.lame_set_in_samplerate(handle,rate);lib.lame_set_out_samplerate(handle,rate);lib.lame_set_num_channels(handle,channels);lib.lame_set_mode(handle,3 if channels==1 else 1);lib.lame_set_brate(handle,128 if rate==44100 else 64);lib.lame_set_error_protection(handle,1);lib.lame_set_bWriteVbrTag(handle,0);assert lib.lame_init_params(handle)==0
    n=rate;left=(np.sin(2*np.pi*997*np.arange(n)/rate)*3000).astype(np.int16);right=(np.sin(2*np.pi*333*np.arange(n)/rate)*1500).astype(np.int16);buffer=(ctypes.c_ubyte*(n*2+7200))()
    size=lib.lame_encode_buffer(handle,left.ctypes.data_as(ctypes.POINTER(ctypes.c_short)),right.ctypes.data_as(ctypes.POINTER(ctypes.c_short)),n,buffer,len(buffer));assert size>=0;encoded=bytes(buffer[:size]);size=lib.lame_encode_flush(handle,buffer,len(buffer));assert size>=0;encoded+=bytes(buffer[:size]);lib.lame_close(handle)
    f=work/f'lame-crc-{rate}-{channels}.mp3';f.write_bytes(encoded);assert encoded[1]&1==0;out=work/f'lame-crc-{rate}-{channels}-out.mp3';java('apply',f,out,3);bit_check(f,out,3);baseline=pcm(f);decoded=pcm(out)
    check(f'real CRC PCM scaling {rate}Hz {channels}ch',len(decoded)==len(baseline) and np.linalg.norm(decoded-baseline*2**(.75))/np.linalg.norm(baseline)<2e-5)
    restored=work/f'lame-crc-{rate}-{channels}-restored.mp3';java('undo',out,restored,0);check(f'real CRC exact Undo {rate}Hz {channels}ch',audio(restored)==audio(f))
check('manual clipping warning predicate',java('clip',.95,1)=='true' and java('clip',.95,-1)=='false')
check('future multi-file track planning',java('batch',fixtures[0],fixtures[1])=='2')

# ID3v2.2 with its own TXX Undo and legacy PIC/art frames.
a=audio(src)
def sync(n):return bytes((n>>21&127,n>>14&127,n>>7&127,n&127))
def frame22(name,data):return name.encode()+len(data).to_bytes(3,'big')+data
body=frame22('TT2',b'\0legacy-title')+frame22('TXX',b'\0REPLAYGAIN_TRACK_GAIN\0-4 dB')+frame22('PIC',b'\0PNG\3\0image-kept')
v22=work/'v22.mp3';v22.write_bytes(b'ID3\2\0\0'+sync(len(body))+body+a);v22out=work/'v22-out.mp3';v22undo=work/'v22-undo.mp3';java('apply',v22,v22out,1);java('undo',v22out,v22undo,0)
check('ID3v2.2 Undo and cover preserved',audio(v22)==audio(v22undo) and v22out.read_bytes()[3]==2 and ID3(v22out).getall('APIC')[0].data==b'image-kept')
# APE remains byte-identical; ID3v1 metadata is migrated by existing editor.
ape=b'APETAGEX'+struct.pack('<6I',2000,32,0,0,0,0);withape=work/'ape.mp3';withape.write_bytes(src.read_bytes()+ape);apeout=work/'ape-out.mp3';java('apply',withape,apeout,-1);bit_check(withape,apeout,-1);check('opaque APE tail preserved',apeout.read_bytes()[-32:]==ape)
legacy=work/'id3v1.mp3';legacy.write_bytes(a+b'TAG'+b'legacy'.ljust(30,b'\0')+b'artist'.ljust(30,b'\0')+b'album'.ljust(30,b'\0')+b'2026'+bytes(30)+b'\xff');legacyout=work/'id3v1-out.mp3';java('apply',legacy,legacyout,-1);check('ID3v1 migration keeps audio and title',str(ID3(legacyout)['TIT2'])=='legacy');bit_check(legacy,legacyout,-1)
# Independently construct CRC-protected frames for all MPEG versions/channel modes.
for version in [3,2,0]:
    for channels in [1,2]:
        rate=44100//(1 if version==3 else 2 if version==2 else 4);bitrate=128 if version==3 else 64;index=9 if version==3 else 8
        length=(144000 if version==3 else 72000)*bitrate//rate;h=bytes([255,224|(version<<3)|2,index<<4,192 if channels==1 else 0]);size=(17 if channels==1 else 32) if version==3 else (9 if channels==1 else 17)
        frame=h+bytes(length-4);lead=9+(5 if channels==1 else 3)+4*channels if version==3 else 8+(1 if channels==1 else 2)
        for i in range((2 if version==3 else 1)*channels):
            bit=48+lead+i*(59 if version==3 else 63);frame=putbits(frame,bit,12,1);frame=putbits(frame,bit+21,8,150+i)
        frame=frame[:4]+crc(frame,6,size).to_bytes(2,'big')+frame[6:];f=work/f'crc-{version}-{channels}.mp3';f.write_bytes(frame*3);out=work/f'crc-{version}-{channels}-out.mp3';java('apply',f,out,2);bit_check(f,out,2);restored=work/f'crc-{version}-{channels}-undo.mp3';java('undo',out,restored,0)
        check(f'CRC edit and exact Undo MPEG{version} channels{channels}',audio(f)==audio(restored))
        broken=work/f'crc-broken-{version}-{channels}.mp3';data=bytearray(f.read_bytes());data[4]^=1;broken.write_bytes(data);rejects(f'reject invalid CRC {version} {channels}','inspect',broken)

for label,data in [('truncated',audio(src)[:-1]),('trailing junk',audio(src)+b'junk'),('free format',b'\xff\xfb\x00\x00'+bytes(100)),('mixed format',audio(src)+audio(fixtures[4]))]:
    f=work/f'bad-{len(checks)}.mp3';f.write_bytes(data);original=f.read_bytes();rejects('reject '+label,'apply',f,work/f'rejected-{len(checks)}.mp3',1);check('preserves '+label,original==f.read_bytes())
flac=work/'test.flac';run('ffmpeg','-v','error','-f','lavfi','-i','sine=duration=0.2','-y',flac);rejects('reject FLAC','inspect',flac)
result={'passed':len(checks),'checks':checks,'verification':'Original C ReplayGain comparison; independent MPEG/CRC bit masks; FFmpeg float PCM scaling and exact Undo; Mutagen tag/cover preservation; rejected bad inputs leave original intact.'}
(ROOT/'mp3gain-test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
