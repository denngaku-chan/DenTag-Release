"""ReplayGain round trips and audio/other-tag preservation with independent readers."""
import hashlib,json,pathlib,struct,subprocess,tempfile
from mutagen.id3 import ID3,TXXX,TIT2
from mutagen.flac import FLAC
ROOT=pathlib.Path(__file__).resolve().parents[1]
CP=ROOT/'build/test-classes'
work=pathlib.Path(tempfile.mkdtemp(prefix='dentag-gain-'))
checks=[]
def run(*args):return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
def gain(*args):return run('java','-cp',str(CP),'jp.dengaku.dentag.GainHarness',*(str(a) for a in args)).decode().strip()
def pcm(path):return hashlib.sha256(run('ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-f','s16le','-')).digest()
def sync(v):return bytes((v>>21&127,v>>14&127,v>>7&127,v&127))
def frame2(key,value):
    data=b'\0'+key.encode()+b'\0'+value.encode();return b'TXX'+len(data).to_bytes(3,'big')+data
base=work/'base.mp3';run('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=0.2','-y',str(base))
audio=base.read_bytes()
if audio.startswith(b'ID3'):
    size=0
    for b in audio[6:10]:size=size*128+b
    audio=audio[10+size:]
for format in ['v22','v23','v24','flac']:
    src=work/(format+('.flac' if format=='flac' else '.mp3'))
    if format=='flac':
        run('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=0.2','-y',str(src))
        t=FLAC(src);t['title']='元の曲 🎵';t['replaygain_track_gain']='-6.00 dB';t['replaygain_album_gain']='-4.00 dB';t['replaygain_track_peak']='0.9';t['lyrics']='歌詞保持';t.save()
    elif format=='v22':
        body=frame2('replaygain_track_gain','-6.00 dB')+frame2('REPLAYGAIN_TRACK_GAIN','-3.00 dB')+frame2('REPLAYGAIN_ALBUM_GAIN','-4.00 dB')+frame2('REPLAYGAIN_TRACK_PEAK','0.9')
        src.write_bytes(b'ID3\x02\0\0'+sync(len(body))+body+audio)
    else:
        src.write_bytes(audio);t=ID3();t.add(TIT2(encoding=1,text=['元の曲 🎵']))
        for key,value in [('replaygain_track_gain','-6.00 dB'),('REPLAYGAIN_TRACK_GAIN','-3.00 dB'),('REPLAYGAIN_ALBUM_GAIN','-4.00 dB'),('REPLAYGAIN_TRACK_PEAK','0.9'),('NOTE','日本語保持')]:t.add(TXXX(encoding=1,desc=key,text=[value]))
        t.save(src,v2_version=3 if format=='v23' else 4)
    baseline=pcm(src);original=src.read_bytes()
    source_gain=gain(src);assert source_gain in ('-6.00 dB','-3.00 dB'), (format,source_gain)
    for requested,expected in [('KEEP',source_gain),('+3','+3.00 dB'),('-4.25','-4.25 dB'),('0','+0.00 dB'),('',''),('−2.5','-2.50 dB')]:
        dst=work/(format+'-'+str(len(checks))+src.suffix)
        assert gain(src,dst,requested)==expected
        assert pcm(dst)==baseline
        assert src.read_bytes()==original
        if format=='flac':
            t=FLAC(dst);assert t.get('replaygain_track_gain',[])==([expected] if expected else [])
            assert t['replaygain_album_gain']==['-4.00 dB'];assert t['replaygain_track_peak']==['0.9'];assert t['lyrics']==['歌詞保持'];assert t['title']==['元の曲 🎵']
        else:
            t=ID3(dst);custom={f.desc:list(f.text) for f in t.getall('TXXX')}
            matching=[v for k,v in custom.items() if k.upper()=='REPLAYGAIN_TRACK_GAIN']
            assert sorted(matching)==(sorted([['-6.00 dB'],['-3.00 dB']]) if requested=='KEEP' else [[expected]] if expected else []), (format,requested,matching)
            assert custom['REPLAYGAIN_ALBUM_GAIN']==['-4.00 dB'];assert custom['REPLAYGAIN_TRACK_PEAK']==['0.9']
            if format!='v22':assert custom['NOTE']==['日本語保持'];assert str(t['TIT2'])=='元の曲 🎵'
        checks.append(format+' '+(requested or 'clear'))
# No prior gain, including FLAC comments absent and tagless MP3.
for fmt in ('mp3','flac'):
    src=work/('fresh.'+fmt);run('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=500:duration=0.2','-y',str(src))
    assert gain(src)=='';dst=work/('fresh-out.'+fmt);assert gain(src,dst,'+1.5')=='+1.50 dB';assert pcm(src)==pcm(dst);checks.append(fmt+' add new gain')
for value,expected in [('-60','-60.00 dB'),('+60','+60.00 dB'),(' 3.456 dB ','+3.46 dB'),('-0','+0.00 dB'),('.5','+0.50 dB')]:assert gain('normalize',value)==expected;checks.append('normalize '+value)
for value in ['NaN','Infinity','1e3','61','-60.001','abc','3,5','0\nINVALID']:
    try:gain('normalize',value)
    except subprocess.CalledProcessError:checks.append('reject '+value)
    else:raise AssertionError('Invalid gain accepted: '+value)
result={'passed':len(checks),'checks':checks,'verification':'Mutagen checks gain and preserved album gain/peak/other metadata; FFmpeg decoded PCM matches; original files unchanged.'}
(ROOT/'gain-test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
