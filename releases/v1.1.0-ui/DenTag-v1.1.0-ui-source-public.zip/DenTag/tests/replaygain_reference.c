#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "gain_analysis.h"
static double read_double(FILE *file){unsigned char b[8];uint64_t bits=0;double value;if(fread(b,1,8,file)!=8)exit(3);for(int i=0;i<8;i++)bits=(bits<<8)|b[i];memcpy(&value,&bits,8);return value;}
int main(int argc,char **argv){if(argc!=3)return 2;FILE *file=fopen(argv[2],"rb");if(!file||!InitGainAnalysis(atol(argv[1])))return 2;Float_t left[733],right[733];for(;;){int count=0;while(count<733){int c=fgetc(file);if(c==EOF)break;ungetc(c,file);left[count]=read_double(file)*32768;right[count]=read_double(file)*32768;count++;}if(!count)break;if(!AnalyzeSamples(left,right,count,2))return 4;}printf("%.8f\n",GetTitleGain());fclose(file);return 0;}
