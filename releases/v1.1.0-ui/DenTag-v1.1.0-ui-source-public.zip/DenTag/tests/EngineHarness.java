package jp.dengaku.dentag;
import java.io.*;
public class EngineHarness {
    public static void main(String[] args) throws Exception {
        File source=new File(args[0]);TagEngine.Song s=TagEngine.read(source);
        if(args.length==1){System.out.println(s.format+" version="+s.version+" "+java.util.Arrays.toString(s.values)+" cover="+(s.picture==null?0:s.picture.data.length));return;}
        String[] values={"日本語の曲名 🎵","でんがく","テスト・アルバム","3/12","2026","J-Pop"};
        if(args.length>3&&args[3].equals("clear"))values=new String[]{"","","","","",""};
        TagEngine.Picture p=s.picture;boolean changed=false;
        if(args.length>2){changed=true;if(args[2].equals("remove"))p=null;else{byte[] image=java.nio.file.Files.readAllBytes(new File(args[2]).toPath());p=new TagEngine.Picture(image,"image/png",64,64);}}
        TagEngine.write(source,new File(args[1]),s,values,p,changed);
        System.out.println("PASS "+s.format+" audio preserved; "+(changed?(p==null?"art removed":"art replaced"):"art preserved"));
    }
}
