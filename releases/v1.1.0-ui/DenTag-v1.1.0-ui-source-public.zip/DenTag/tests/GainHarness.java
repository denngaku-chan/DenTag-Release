package jp.dengaku.dentag;
import java.io.*;
public final class GainHarness {
    public static void main(String[] args) throws Exception {
        if(args[0].equals("normalize")){System.out.println(TagEngine.normalizeGain(args[1]));return;}
        File source=new File(args[0]);TagEngine.Song song=TagEngine.read(source);
        if(args.length==1){System.out.println(song.trackGain);return;}
        TagEngine.write(source,new File(args[1]),song,song.values,song.picture,false,args[2],!args[2].equals("KEEP"));
        System.out.println(TagEngine.read(new File(args[1])).trackGain);
    }
}
