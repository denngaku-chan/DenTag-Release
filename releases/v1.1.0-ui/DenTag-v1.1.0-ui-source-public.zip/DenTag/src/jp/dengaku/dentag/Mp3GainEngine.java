package jp.dengaku.dentag;

import java.io.*;
import java.util.*;

/** Layer III gain edits. Only active global_gain bits and their protected CRC may change. */
public final class Mp3GainEngine {
    public static final double STEP_DB=5.0*Math.log10(2.0);
    public static final String UNDO_KEY="DENTAG_MP3GAIN_UNDO";
    private static final int[] MPEG1={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320};
    private static final int[] MPEG2={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160};
    public static final class Info {
        public int sampleRate,channels,minGain=255,maxGain=0;
        public long frames,activeSlots;
        public String audioHash;
        public int minimumSteps(){return activeSlots==0?0:-minGain;}
        public int maximumSteps(){return activeSlots==0?0:255-maxGain;}
    }
    public static final class Undo {
        public final int steps;public final String originalHash,currentHash;
        private Undo(int n,String original,String current){steps=n;originalHash=original;currentHash=current;}
        public String encode(){return "1|"+steps+"|"+originalHash+"|"+currentHash;}
        public static Undo parse(String text) throws IOException {
            String[] p=text.split("\\|",-1);
            try{if(p.length!=4||!p[0].equals("1")||!p[2].matches("[0-9a-f]{64}")||!p[3].matches("[0-9a-f]{64}"))throw new IllegalArgumentException();int n=Integer.parseInt(p[1]);if(n==0||n< -255||n>255)throw new IllegalArgumentException();return new Undo(n,p[2],p[3]);}
            catch(RuntimeException e){throw new IOException("MP3GainのUndo情報が正しくありません。",e);}
        }
    }
    public static final class Prepared {
        public final int appliedSteps;public final String undo;
        Prepared(int steps,String value){appliedSteps=steps;undo=value;}
    }
    /** File-independent measurements/plans allow a future multi-selection UI. */
    public static final class TrackMeasurement {
        public final File source;public final Info info;public final double gainAt89,peak;
        public TrackMeasurement(File source,Info info,double gainAt89,double peak) throws IOException {
            if(info==null||info.audioHash==null||!Double.isFinite(gainAt89)||!Double.isFinite(peak)||peak<0)throw new IOException("音量解析結果が正しくありません。");
            this.source=source;this.info=info;this.gainAt89=gainAt89;this.peak=peak;
        }
    }
    public static final class TrackPlan {
        public final TrackMeasurement measurement;public final int steps;
        private TrackPlan(TrackMeasurement m,int steps){measurement=m;this.steps=steps;}
    }
    /** Track gain: each song has its own target adjustment; does not alter files. */
    public static List<TrackPlan> planTracks(Iterable<TrackMeasurement> measurements,double target) throws IOException {
        List<TrackPlan> plans=new ArrayList<>();
        for(TrackMeasurement m:measurements)plans.add(new TrackPlan(m,recommendedSteps(m.gainAt89,target,m.info,m.peak)));
        return Collections.unmodifiableList(plans);
    }
    public static Prepared prepareTrack(TrackPlan plan,File destination) throws IOException {
        if(!plan.measurement.info.audioHash.equals(inspect(plan.measurement.source).audioHash))throw new IOException("解析後に音声が変更されました。解析し直してください。");
        return prepare(plan.measurement.source,destination,plan.steps,false);
    }
    private static final class Frame {
        int length,rate,channels,sideStart,sideLength,version;
        boolean crc;int[] slots;boolean[] active;
    }
    private interface Visitor {void visit(long position,byte[] bytes,Frame f) throws IOException;}
    private static int get(byte[] b,int bit,int count){int n=0;for(int i=0;i<count;i++)n=(n<<1)|((b[(bit+i)/8]>>(7-(bit+i)%8))&1);return n;}
    private static void put(byte[] b,int bit,int count,int value){for(int i=0;i<count;i++){int index=(bit+i)/8,mask=1<<(7-(bit+i)%8);b[index]=(byte)((b[index]&~mask)|(((value>>(count-1-i))&1)!=0?mask:0));}}
    private static Frame header(byte[] h) throws IOException {
        int a=h[1]&255,b=h[2]&255,c=h[3]&255;
        if((h[0]&255)!=255||(a&224)!=224||(a&6)!=2||(a&24)==8||(b&12)==12||(c&3)==2)throw new IOException("対応するMP3フレームが見つかりません。破損・特殊形式の曲には適用できません。");
        int version=(a>>3)&3,bitrate=(b>>4)&15;
        if(bitrate==0||bitrate==15)throw new IOException("フリーフォーマットなどの特殊なMP3には対応していません。");
        Frame f=new Frame();f.version=version;f.crc=(a&1)==0;f.channels=(c>>6)==3?1:2;
        f.rate=new int[]{44100,48000,32000}[(b>>2)&3]/(version==3?1:version==2?2:4);
        f.length=(version==3?144000:72000)*(version==3?MPEG1:MPEG2)[bitrate]/f.rate+((b>>1)&1);
        f.sideStart=f.crc?6:4;f.sideLength=version==3?(f.channels==1?17:32):(f.channels==1?9:17);
        if(f.length<f.sideStart+f.sideLength)throw new IOException("MP3フレームの長さが正しくありません。");
        int lead=version==3?9+(f.channels==1?5:3)+4*f.channels:8+(f.channels==1?1:2);
        int granules=version==3?2:1,stride=version==3?59:63;
        f.slots=new int[granules*f.channels];f.active=new boolean[f.slots.length];
        for(int i=0;i<f.slots.length;i++)f.slots[i]=f.sideStart*8+lead+stride*i+21;
        return f;
    }
    private static int crc(byte[] b,Frame f){int result=0xffff;for(int i=2;i<f.sideStart+f.sideLength;i++){if(i==4||i==5)continue;int value=b[i]&255;for(int bit=7;bit>=0;bit--){int flag=((result>>15)&1)^((value>>bit)&1);result=(result<<1)&65535;if(flag!=0)result^=0x8005;}}return result;}
    private static void checkCrc(byte[] b,Frame f) throws IOException {if(f.crc&&(((b[4]&255)<<8)|(b[5]&255))!=crc(b,f))throw new IOException("CRCが一致しないMP3フレームがあるため、MP3Gainを中止しました。");}
    private static long little(byte[] b,int p){long n=0;for(int i=3;i>=0;i--)n=(n<<8)|(b[p+i]&255);return n;}
    private static long frameEnd(RandomAccessFile r,TagEngine.Song song) throws IOException {
        long end=song.audioEnd;
        if(end-song.audioStart>=32){byte[] footer=new byte[32];r.seek(end-32);r.readFully(footer);
            if(new String(footer,0,8,"ISO-8859-1").equals("APETAGEX")){
                long size=little(footer,12),count=little(footer,16),flags=little(footer,20);
                if(size<32||size>32*1024*1024||size>end-song.audioStart||count>size/8)throw new IOException("末尾のAPEタグが破損しています。");
                end-=size;
                if((flags&0x80000000L)!=0){if(end-song.audioStart<32)throw new IOException("APEヘッダーが破損しています。");byte[] h=new byte[32];r.seek(end-32);r.readFully(h);if(!new String(h,0,8,"ISO-8859-1").equals("APETAGEX"))throw new IOException("APEヘッダーを確認できませんでした。");end-=32;}
            }
        }
        return end;
    }
    private static Info walk(File file,TagEngine.Song song,Visitor visitor) throws IOException {
        if(!"MP3".equals(song.format))throw new IOException("MP3GainはMP3ファイル専用です。");
        Info info=new Info();try(RandomAccessFile r=new RandomAccessFile(file,"r")){
            long end=frameEnd(r,song),p=song.audioStart;
            while(p<end){if(Thread.currentThread().isInterrupted())throw new IOException("MP3Gainを中断しました。");
                if(end-p<4)throw new IOException("MP3が途中で切れています。");byte[] h=new byte[4];r.seek(p);r.readFully(h);
                Frame f=header(h);if(p+f.length>end)throw new IOException("MP3が途中で切れています。");
                byte[] data=new byte[f.length];r.seek(p);r.readFully(data);checkCrc(data,f);
                if(info.frames==0){info.sampleRate=f.rate;info.channels=f.channels;}else if(info.sampleRate!=f.rate||info.channels!=f.channels)throw new IOException("途中で音声形式が変わるMP3には対応していません。");
                for(int i=0;i<f.slots.length;i++){
                    f.active[i]=get(data,f.slots[i]-21,12)>0;
                    if(f.active[i]){int gain=get(data,f.slots[i],8);info.minGain=Math.min(info.minGain,gain);info.maxGain=Math.max(info.maxGain,gain);info.activeSlots++;}
                }
                if(visitor!=null)visitor.visit(p,data,f);info.frames++;p+=f.length;
            }
        }
        if(info.frames==0)throw new IOException("MP3の音声フレームがありません。");
        info.audioHash=hex(TagEngine.audioHash(file,song));return info;
    }
    public static Info inspect(File file) throws IOException {TagEngine.Song song=TagEngine.read(file);return walk(file,song,null);}
    private static String hex(byte[] data){StringBuilder b=new StringBuilder();for(byte x:data)b.append(String.format(Locale.ROOT,"%02x",x&255));return b.toString();}
    public static Undo verifiedUndo(File file,TagEngine.Song song) throws IOException {
        if(song.mp3GainUndo.isEmpty())throw new IOException("この曲にはDenTagのMP3Gain Undo情報がありません。");
        Undo undo=Undo.parse(song.mp3GainUndo);Info info=inspect(file);
        if(!undo.currentHash.equals(info.audioHash))throw new IOException("MP3の音声部分が変更されているため、安全にUndoできません。");
        checkSteps(info,-undo.steps);return undo;
    }
    public static void checkSteps(Info info,int steps) throws IOException {if(steps<info.minimumSteps()||steps>info.maximumSteps())throw new IOException("この変更ではMP3の音量値が範囲外になります。変更量を小さくしてください。");}
    public static int recommendedSteps(double gainAt89,double target,Info info,double peak) throws IOException {
        if(Double.isNaN(target)||Double.isInfinite(target)||target<70||target>100)throw new IOException("目標音量は70〜100 dBで入力してください。");
        int steps=(int)Math.round((gainAt89+target-89)/STEP_DB);
        // Small headroom margin for decoder rounding; never wrap or clamp individual gains.
        if(peak>0){int safe=(int)Math.floor(20*Math.log10(0.999/peak)/STEP_DB);steps=Math.min(steps,safe);}
        return Math.max(info.minimumSteps(),Math.min(info.maximumSteps(),steps));
    }
    public static boolean clipping(double peak,int steps){return peak*Math.pow(2.0,steps/4.0)>1.0;}
    public static Prepared prepare(File source,File destination,int requestedSteps,boolean undoRequested) throws IOException {
        if(source.getCanonicalFile().equals(destination.getCanonicalFile()))throw new IOException("元の曲を直接処理できません。");
        TagEngine.Song song=TagEngine.read(source);Info info=inspect(source);Undo previous=null;
        if(!song.mp3GainUndo.isEmpty())previous=verifiedUndo(source,song);
        int steps=undoRequested?(previous==null?0:-previous.steps):requestedSteps;
        if(undoRequested&&previous==null)throw new IOException("Undo情報がありません。");checkSteps(info,steps);
        try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(destination)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
        try(RandomAccessFile result=new RandomAccessFile(destination,"rw")){
            walk(source,song,(position,bytes,frame)->{
                if(steps==0)return;
                for(int i=0;i<frame.slots.length;i++)if(frame.active[i])put(bytes,frame.slots[i],8,get(bytes,frame.slots[i],8)+steps);
                if(frame.crc){int c=crc(bytes,frame);bytes[4]=(byte)(c>>8);bytes[5]=(byte)c;}
                result.seek(position);result.write(bytes);
            });result.getFD().sync();
        }
        verifyTransform(source,destination,steps);
        String newHash=inspect(destination).audioHash;
        int total=(previous==null?0:previous.steps)+steps;String original=previous==null?info.audioHash:previous.originalHash;
        if(total==0){if(!original.equals(newHash))throw new IOException("Undo後の元データと一致しません。");return new Prepared(steps,"");}
        if(total< -255||total>255)throw new IOException("累積音量変更が範囲外です。先にUndoしてください。");
        return new Prepared(steps,new Undo(total,original,newHash).encode());
    }
    /** Also verifies a re-tagged result whose ID3 size (and audio offset) changed. */
    public static void verifyTransform(File source,File result,int steps) throws IOException {
        TagEngine.Song original=TagEngine.read(source),updated=TagEngine.read(result);
        if(!"MP3".equals(updated.format)||original.audioEnd-original.audioStart!=updated.audioEnd-updated.audioStart)throw new IOException("音声データの長さが変わっています。");
        try(RandomAccessFile out=new RandomAccessFile(result,"r")){
            Info before=walk(source,original,(position,expected,f)->{
                for(int i=0;i<f.slots.length;i++)if(f.active[i]){int value=get(expected,f.slots[i],8)+steps;if(value<0||value>255)throw new IOException("音量値が範囲外です。");put(expected,f.slots[i],8,value);}
                if(f.crc&&steps!=0){int c=crc(expected,f);expected[4]=(byte)(c>>8);expected[5]=(byte)c;}
                byte[] actual=new byte[expected.length];out.seek(updated.audioStart+position-original.audioStart);out.readFully(actual);
                if(!Arrays.equals(expected,actual))throw new IOException("音量値・CRC以外のMP3データが変わっています。");
            });
            try(RandomAccessFile in=new RandomAccessFile(source,"r")){
                long end=frameEnd(in,original),remaining=original.audioEnd-end;
                in.seek(end);out.seek(updated.audioStart+end-original.audioStart);byte[] a=new byte[65536],b=new byte[65536];
                while(remaining>0){int n=(int)Math.min(remaining,a.length);in.readFully(a,0,n);out.readFully(b,0,n);for(int i=0;i<n;i++)if(a[i]!=b[i])throw new IOException("MP3末尾のタグが変わっています。");remaining-=n;}
            }
            if(before.frames!=inspect(result).frames)throw new IOException("MP3のフレーム数が変わっています。");
        }
    }
    private Mp3GainEngine(){}
}
