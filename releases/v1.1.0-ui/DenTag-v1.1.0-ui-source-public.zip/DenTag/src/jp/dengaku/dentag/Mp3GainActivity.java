package jp.dengaku.dentag;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public final class Mp3GainActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Button> buttons=new ArrayList<>();
    private Mp3GainAnalyzer.Result analysis;private Mp3GainEngine.Undo savedUndo;
    private File source;private int steps;private boolean undo;
    private int ink,muted,bg,card,accent,line;private TextView results,planned,state;private EditText target;
    private Button minus,plus,restore,apply;private ProgressBar progress;
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setLineSpacing(dp(4),1);return t;}
    private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));return d;}
    private void gap(LinearLayout p){p.addView(new View(this),new LinearLayout.LayoutParams(1,dp(14)));}
    private android.graphics.drawable.Drawable buttonBackground(int color,boolean outlined){GradientDrawable surface=shape(color);if(outlined)surface.setStroke(dp(1),line);StateListDrawable states=new StateListDrawable();states.addState(new int[]{-android.R.attr.state_enabled},shape(line));states.addState(new int[]{},new RippleDrawable(ColorStateList.valueOf((accent&0x00FFFFFF)|0x20000000),surface,shape(Color.WHITE)));return states;}
    private Button button(LinearLayout p,String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(new ColorStateList(new int[][]{{android.R.attr.state_enabled},{}},new int[]{accent,muted}));b.setTextSize(15);b.setMinWidth(0);b.setMinHeight(dp(54));b.setPadding(dp(14),dp(10),dp(14),dp(10));b.setBackground(buttonBackground(card,false));p.addView(b,new LinearLayout.LayoutParams(-1,-2));buttons.add(b);return b;}
    @Override public void onCreate(Bundle bundle){super.onCreate(bundle);
        boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        bg=Color.parseColor(dark?"#171C19":"#F6F5EF");card=Color.parseColor(dark?"#232C26":"#FFFFFF");ink=Color.parseColor(dark?"#F2F3EA":"#21372C");muted=Color.parseColor(dark?"#ACBCB0":"#677A6E");accent=Color.parseColor(dark?"#B5D5AF":"#355C4A");
        line=Color.parseColor(dark?"#3E5143":"#DDE5DB");
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(bg);
        if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);outer.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});}
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(18),dp(20),dp(20));scroll.addView(content);setContentView(outer);outer.requestApplyInsets();
        TextView title=text("MP3Gain",28,ink);title.setTypeface(null,Typeface.BOLD);content.addView(title);gap(content);
        content.addView(text("MP3本体の音量を変更します。ReplayGain非対応プレーヤーでも反映されます。\n再エンコードは行いません。",14,muted));gap(content);
        content.addView(text("現在の解析結果",18,ink));results=text("解析しています…",16,ink);content.addView(results);gap(content);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);content.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));state=text("曲を解析しています…",12,muted);content.addView(state);gap(content);
        content.addView(text("目標音量（dB）",13,muted));target=new EditText(this);target.setSingleLine(true);target.setTextSize(18);target.setTextColor(ink);target.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);target.setBackground(shape(card));target.setPadding(dp(14),dp(10),dp(14),dp(10));target.setText(bundle==null?getSharedPreferences("mp3gain",0).getString("target","89"):bundle.getString("target","89"));content.addView(target,new LinearLayout.LayoutParams(-1,dp(54)));gap(content);
        target.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh();}public void afterTextChanged(android.text.Editable s){}});
        Button auto=button(content,"音量を自動調整");auto.setOnClickListener(v->{try{double value=targetValue();steps=Mp3GainEngine.recommendedSteps(analysis.gainAt89,value,analysis.info,analysis.peak);undo=false;getSharedPreferences("mp3gain",0).edit().putString("target",target.getText().toString()).apply();refresh();}catch(Exception e){target.setError(e.getMessage());}});gap(content);
        content.addView(text("手動調整（約1.5 dB刻み）",13,muted));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);content.addView(row,new LinearLayout.LayoutParams(-1,dp(54)));
        minus=new Button(this);minus.setText("−");minus.setTextColor(accent);row.addView(minus,new LinearLayout.LayoutParams(dp(62),-1));buttons.add(minus);
        planned=text("0.0 dB",22,ink);planned.setGravity(Gravity.CENTER);row.addView(planned,new LinearLayout.LayoutParams(0,-1,1));
        plus=new Button(this);plus.setText("＋");plus.setTextColor(accent);row.addView(plus,new LinearLayout.LayoutParams(dp(62),-1));buttons.add(plus);
        minus.setOnClickListener(v->adjust(-1));plus.setOnClickListener(v->adjust(1));gap(content);
        LinearLayout editActions=new LinearLayout(this);editActions.setGravity(Gravity.CENTER_VERTICAL);content.addView(editActions,new LinearLayout.LayoutParams(-1,-2));
        restore=button(editActions,"元に戻す（Undo）");restore.setTextSize(14);restore.setBackground(buttonBackground(card,true));restore.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));restore.setOnClickListener(v->{steps=-savedUndo.steps;undo=true;refresh();});
        editActions.addView(new Space(this),new LinearLayout.LayoutParams(dp(10),1));Button clear=button(editActions,"変更予約を解除");clear.setTextSize(14);clear.setBackground(buttonBackground(card,true));clear.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));clear.setOnClickListener(v->{steps=0;undo=false;refresh();});gap(content);
        LinearLayout help=new LinearLayout(this);help.setOrientation(LinearLayout.VERTICAL);help.setBackground(shape(card));help.setPadding(dp(18),dp(16),dp(18),dp(16));TextView helpTitle=text("保存は編集画面で",14,ink);helpTitle.setTypeface(null,Typeface.BOLD);help.addView(helpTitle);
        TextView saveHint=text("戻ったあとに「保存する」を押して、上書き保存・コピー保存を選びます。",13,muted);saveHint.setPadding(0,dp(6),0,dp(12));help.addView(saveHint);help.addView(text("表示音量はReplayGain基準の推定値です。端末の音量や実際の音圧ではありません。\nUndoはDenTagが保存した情報を使用します。",12,muted));content.addView(help);gap(content);
        Button license=button(content,"音量解析ライブラリのライセンス");license.setTextSize(12);license.setMinHeight(dp(48));license.setBackground(new RippleDrawable(ColorStateList.valueOf(line),shape(Color.TRANSPARENT),shape(Color.WHITE)));license.setOnClickListener(v->showLicense());
        View divider=new View(this);divider.setBackgroundColor(line);outer.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));LinearLayout footer=new LinearLayout(this);footer.setOrientation(LinearLayout.VERTICAL);footer.setBackgroundColor(bg);footer.setPadding(dp(20),dp(12),dp(20),dp(14));outer.addView(footer,new LinearLayout.LayoutParams(-1,-2));
        TextView footerHint=text("この画面では、変更を予約します",12,muted);footerHint.setGravity(Gravity.CENTER);footerHint.setPadding(0,0,0,dp(10));footer.addView(footerHint);LinearLayout navigation=new LinearLayout(this);navigation.setGravity(Gravity.CENTER_VERTICAL);footer.addView(navigation,new LinearLayout.LayoutParams(-1,-2));
        Button cancel=button(navigation,"キャンセル");cancel.setBackground(buttonBackground(card,true));cancel.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));cancel.setOnClickListener(v->finish());navigation.addView(new Space(this),new LinearLayout.LayoutParams(dp(10),1));
        apply=button(navigation,"設定を使って戻る");apply.setTextColor(new ColorStateList(new int[][]{{android.R.attr.state_enabled},{}},new int[]{bg,muted}));apply.setBackground(buttonBackground(accent,false));apply.setTypeface(null,Typeface.BOLD);apply.setLayoutParams(new LinearLayout.LayoutParams(0,-2,2));apply.setOnClickListener(v->confirm());
        for(Button b:buttons)b.setEnabled(b==cancel||b==license);target.setEnabled(false);
        String path=getIntent().getStringExtra("source");if(path==null){state.setText("曲を開き直してください。");return;}source=new File(path);
        steps=bundle==null?getIntent().getIntExtra("steps",0):bundle.getInt("steps");undo=bundle==null?getIntent().getBooleanExtra("undo",false):bundle.getBoolean("undo");
        worker.execute(()->{try{Mp3GainAnalyzer.Result a=Mp3GainAnalyzer.analyze(source,p->runOnUiThread(()->{if(!isDestroyed()){progress.setProgress(p);state.setText("音量を解析しています… "+p+"%");}}));Mp3GainEngine.Undo u=null;String undoNote="Undo情報なし";TagEngine.Song song=TagEngine.read(source);
            if(!song.mp3GainUndo.isEmpty()){try{u=Mp3GainEngine.verifiedUndo(source,song);undoNote="元に戻せます";}catch(IOException e){undoNote=e.getMessage();}}
            final Mp3GainEngine.Undo parsed=u;final String note=undoNote;runOnUiThread(()->{if(isDestroyed())return;analysis=a;savedUndo=parsed;if(undo){if(parsed!=null)steps=-parsed.steps;else{undo=false;steps=0;}}steps=Math.max(a.info.minimumSteps(),Math.min(a.info.maximumSteps(),steps));for(Button b:buttons)b.setEnabled(true);target.setEnabled(true);progress.setVisibility(View.GONE);state.setText(note+(a.peakLimited?"\nこの端末のピーク値は16 bit PCMによる推定です。":""));refresh();});
        }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;progress.setVisibility(View.GONE);results.setText("解析できませんでした");state.setText(e.getMessage());});}});
    }
    private double targetValue() throws IOException {try{double value=Double.parseDouble(target.getText().toString());if(Double.isNaN(value)||Double.isInfinite(value)||value<70||value>100)throw new NumberFormatException();return value;}catch(RuntimeException e){throw new IOException("目標音量は70〜100 dBで入力してください。");}}
    private void adjust(int delta){int next=steps+delta;if(next>=analysis.info.minimumSteps()&&next<=analysis.info.maximumSteps()){steps=next;undo=false;refresh();}}
    private void refresh(){if(analysis==null)return;double recommended=analysis.gainAt89;String recommendation=String.format(Locale.JAPAN,"%+.1f dB",recommended);
        try{int n=Mp3GainEngine.recommendedSteps(recommended,targetValue(),analysis.info,analysis.peak);recommendation=String.format(Locale.JAPAN,"%+.1f dB（ピーク値に基づく推奨値）",n*Mp3GainEngine.STEP_DB);}catch(IOException ignored){}
        results.setText(String.format(Locale.JAPAN,"現在の推定音量　%.1f dB\n推奨変更　%s\n適用予定　%+.1f dB%s\n適用後　約 %.1f dB\nクリッピング　%s",analysis.loudness(),recommendation,steps*Mp3GainEngine.STEP_DB,undo?"（Undo）":"",analysis.loudness()+steps*Mp3GainEngine.STEP_DB,analysis.mayClip(steps)?"可能性あり":"予測なし"));
        planned.setText(String.format(Locale.JAPAN,"%+.1f dB",steps*Mp3GainEngine.STEP_DB));minus.setEnabled(steps>analysis.info.minimumSteps());plus.setEnabled(steps<analysis.info.maximumSteps());restore.setEnabled(savedUndo!=null);
    }
    private void confirm(){if(analysis==null)return;if(steps!=0&&analysis.mayClip(steps))new AlertDialog.Builder(this).setTitle("クリッピングの可能性があります").setMessage("この音量ではクリッピングが発生する可能性があります。").setNegativeButton("キャンセル",null).setPositiveButton("このまま適用",(d,w)->complete()).show();else complete();}
    private void complete(){setResult(RESULT_OK,new Intent().putExtra("steps",steps).putExtra("undo",undo).putExtra("audioHash",analysis.info.audioHash));finish();}
    private void showLicense(){try{ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getAssets().open("replaygain-license.txt")){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}TextView text=text(new String(out.toByteArray(),"UTF-8"),12,ink);text.setTextIsSelectable(true);text.setPadding(dp(16),dp(10),dp(16),dp(10));ScrollView scroll=new ScrollView(this);scroll.addView(text);new AlertDialog.Builder(this).setTitle("ReplayGain analysis — LGPL 2.1+").setView(scroll).setPositiveButton("閉じる",null).show();}catch(IOException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("steps",steps);b.putBoolean("undo",undo);b.putString("target",target.getText().toString());}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
