package jp.dengaku.dentag;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int OPEN=10, PHOTO=11, SAVE=12, RECOVER=13, MP3GAIN=14;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<View> controls=new ArrayList<>();
    private final EditText[] fields=new EditText[6];
    private EditText volume;
    private boolean gainChanged;
    private int mp3Steps;private boolean mp3Undo;private String mp3SourceHash="";private Intent deferredMp3;
    private Button mp3Gain;private TextView mp3Note;
    private TextView filename, info, status, artInfo;
    private ImageView cover;
    private Button save, photo, remove;
    private ProgressBar progress;
    private LinearLayout root, songPicker;
    private File source;
    private TagEngine.Song song;
    private TagEngine.Picture picture;
    private String displayName="";
    private boolean artworkChanged, dirty, busy;
    private Uri deferredSave, deferredRecovery;
    private Uri sourceUri;
    private boolean sourceWritable;
    private int ink, muted, bg, card, accent, line;

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        colors();build();boolean restoring=false;
        if(state!=null){String uri=state.getString("sourceUri");if(uri!=null)sourceUri=Uri.parse(uri);sourceWritable=state.getBoolean("sourceWritable");}
        if(state!=null){String path=state.getString("source");if(path!=null){File f=new File(path);if(f.isFile()){restoring=true;displayName=state.getString("name","");setBusy(true,"編集中の曲を復元しています…");worker.execute(()->{try{TagEngine.Song s=TagEngine.read(f);TagEngine.Picture p=s.picture;boolean changed=state.getBoolean("artChanged");if(changed){String ap=state.getString("picture");if(ap==null)p=null;else{File pf=new File(ap);if(!pf.isFile())throw new IOException("編集中の画像を復元できませんでした。曲を開き直してください。");p=new TagEngine.Picture(readLimited(new FileInputStream(pf),16*1024*1024),state.getString("mime"),state.getInt("width"),state.getInt("height"));}}
                    final TagEngine.Picture rp=p;runOnUiThread(()->{source=f;song=s;picture=rp;artworkChanged=changed;fill();String[] vals=state.getStringArray("values");if(vals!=null)for(int i=0;i<6;i++)fields[i].setText(vals[i]);volume.setText(state.getString("volume",song.trackGain.replaceAll("(?i)\\s*dB$", "")));gainChanged=state.getBoolean("gainChanged");mp3Steps=state.getInt("mp3Steps");mp3Undo=state.getBoolean("mp3Undo");mp3SourceHash=state.getString("mp3Hash","");updateMp3Note();dirty=state.getBoolean("dirty");setBusy(false,"編集を続けられます");if(deferredMp3!=null){Intent value=deferredMp3;deferredMp3=null;applyMp3Result(value);}if(deferredSave!=null){Uri uri=deferredSave;deferredSave=null;export(uri,false);}if(deferredRecovery!=null){Uri uri=deferredRecovery;deferredRecovery=null;recover(uri);}else if(backup().exists())offerRecovery();});
                }catch(Exception e){runOnUiThread(()->{setBusy(false,"曲を選んでください");error(e);if(backup().exists())offerRecovery();});}});}}}
        if(backup().exists()&&!restoring)offerRecovery();
    }
    private void colors(){boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        bg=Color.parseColor(dark?"#171C19":"#F6F5EF");card=Color.parseColor(dark?"#232C26":"#FFFFFF");ink=Color.parseColor(dark?"#F2F3EA":"#21372C");muted=Color.parseColor(dark?"#ACBCB0":"#677A6E");accent=Color.parseColor(dark?"#B5D5AF":"#355C4A");line=Color.parseColor(dark?"#3E5143":"#DDE5DB");
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void gap(LinearLayout p,int n){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(n)));}
    private Button button(String label,boolean filled){Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(filled?bg:accent);b.setBackground(shape(filled?accent:card,14));b.setMinHeight(dp(50));b.setPadding(dp(14),dp(10),dp(14),dp(10));controls.add(b);return b;}
    private void build(){
        root=vertical();root.setBackgroundColor(bg);root.setPadding(dp(20),0,dp(20),0);
        if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(false);root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bar=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(dp(20)+bar.left,bar.top,dp(20)+bar.right,bar.bottom);return insets;});}
        setContentView(root);root.requestApplyInsets();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(0,dp(18),0,dp(16));
        LinearLayout titles=vertical();TextView title=text("DenTag",30,ink);title.setTypeface(null,Typeface.BOLD);titles.addView(title);titles.addView(text("曲の情報と、ジャケットを。",12,muted));top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(top);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=vertical();content.setPadding(0,0,0,dp(16));scroll.addView(content);
        songPicker=new LinearLayout(this);songPicker.setGravity(Gravity.CENTER_VERTICAL);songPicker.setMinimumHeight(dp(84));songPicker.setPadding(dp(18),dp(16),dp(18),dp(16));
        songPicker.setBackground(new RippleDrawable(ColorStateList.valueOf(line),shape(card,20),shape(Color.WHITE,20)));
        songPicker.setFocusable(true);songPicker.setContentDescription("曲を選ぶ。MP3またはFLACを開きます");songPicker.setOnClickListener(v->confirmSwitch());
        songPicker.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo node){super.onInitializeAccessibilityNodeInfo(host,node);node.setClassName(Button.class.getName());}});
        LinearLayout fileText=vertical();filename=text("まずは曲を選んでください",17,ink);filename.setTypeface(null,Typeface.BOLD);filename.setMaxLines(2);filename.setEllipsize(android.text.TextUtils.TruncateAt.END);fileText.addView(filename);gap(fileText,6);info=text("タップして MP3 / FLAC を開く",12,muted);fileText.addView(info);songPicker.addView(fileText,new LinearLayout.LayoutParams(0,-2,1));
        TextView choose=text("›",30,accent);choose.setGravity(Gravity.CENTER);choose.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);LinearLayout.LayoutParams chooseLayout=new LinearLayout.LayoutParams(dp(24),-2);chooseLayout.leftMargin=dp(12);songPicker.addView(choose,chooseLayout);content.addView(songPicker,new LinearLayout.LayoutParams(-1,-2));gap(content,16);
        LinearLayout artCard=vertical();artCard.setGravity(Gravity.CENTER_HORIZONTAL);artCard.setPadding(dp(18),dp(20),dp(18),dp(18));artCard.setBackground(shape(card,20));
        TextView cap=text("ジャケット",12,muted);cap.setGravity(Gravity.CENTER);artCard.addView(cap);gap(artCard,12);
        cover=new ImageView(this);cover.setScaleType(ImageView.ScaleType.FIT_CENTER);cover.setBackground(shape(line,16));cover.setContentDescription("ジャケット画像のプレビュー");artCard.addView(cover,new LinearLayout.LayoutParams(dp(180),dp(180)));
        gap(artCard,10);artInfo=text("画像なし",12,muted);artCard.addView(artInfo);gap(artCard,12);
        LinearLayout artButtons=new LinearLayout(this);photo=button("写真を選ぶ",false);remove=button("画像を削除",false);artButtons.addView(photo,new LinearLayout.LayoutParams(0,dp(50),1));Space space=new Space(this);artButtons.addView(space,new LinearLayout.LayoutParams(dp(10),1));artButtons.addView(remove,new LinearLayout.LayoutParams(0,dp(50),1));artCard.addView(artButtons,new LinearLayout.LayoutParams(-1,-2));content.addView(artCard);
        photo.setOnClickListener(v->launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),PHOTO));
        remove.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("ジャケットを削除しますか？").setMessage("保存時に、埋め込まれたジャケット画像をすべて削除します。").setNegativeButton("キャンセル",null).setPositiveButton("削除",(d,w)->{picture=null;artworkChanged=true;dirty=true;preview();}).show());
        gap(content,18);TextView section=text("曲の情報",18,ink);section.setTypeface(null,Typeface.BOLD);content.addView(section);gap(content,10);
        String[] labels={"曲名","アーティスト","アルバム名","トラック番号","発売年","ジャンル"};String[] hints={"曲のタイトル","アーティスト名","アルバム名","例：1 または 1/12","例：2026","例：Pop、Rock、J-Pop"};
        for(int i=0;i<6;i++){content.addView(text(labels[i],12,muted));gap(content,5);EditText e=new EditText(this);fields[i]=e;e.setTextSize(16);e.setTextColor(ink);e.setHintTextColor(muted);e.setHint(hints[i]);e.setSingleLine(true);e.setSelectAllOnFocus(false);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);e.setBackground(shape(card,12));e.setPadding(dp(16),dp(12),dp(16),dp(12));e.setId(100+i);content.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));controls.add(e);e.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){dirty=true;}public void afterTextChanged(android.text.Editable s){}});gap(content,14);}
        TextView volumeTitle=text("音量補正（ReplayGain）",18,ink);volumeTitle.setTypeface(null,Typeface.BOLD);content.addView(volumeTitle);gap(content,10);
        volume=new EditText(this);volume.setId(110);volume.setSingleLine(true);volume.setTextSize(18);volume.setTextColor(ink);volume.setHintTextColor(muted);
        volume.setHint("未設定（例：-3.0、+3.0）");volume.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_SIGNED|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        volume.setBackground(shape(card,12));volume.setPadding(dp(16),dp(12),dp(16),dp(12));controls.add(volume);
        LinearLayout gainInput=new LinearLayout(this);gainInput.setGravity(Gravity.CENTER_VERTICAL);gainInput.addView(volume,new LinearLayout.LayoutParams(0,dp(54),1));TextView unit=text("dB",16,muted);unit.setPadding(dp(12),0,dp(8),0);gainInput.addView(unit);content.addView(gainInput);
        volume.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){gainChanged=true;dirty=true;}public void afterTextChanged(android.text.Editable s){}});
        gap(content,10);LinearLayout gainButtons=new LinearLayout(this);
        String[] gainLabels={"-1 dB","+1 dB","解除"};for(int i=0;i<3;i++){final int index=i;Button b=button(gainLabels[i],false);b.setTag("song");b.setOnClickListener(v->{if(index==2){volume.setText("");return;}adjustGain(index==0?-1:1);});if(i>0){Space gainSpace=new Space(this);gainButtons.addView(gainSpace,new LinearLayout.LayoutParams(dp(8),1));}gainButtons.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));}
        content.addView(gainButtons);gap(content,10);
        TextView gainNote=text("マイナスで小さく、プラスで大きく。0は補正なし。\n空欄・解除で音量補正タグを削除します。\n対応プレイヤーでReplayGainを有効にし、曲単位（トラック）を選ぶと反映されます。",12,muted);gainNote.setLineSpacing(dp(4),1);content.addView(gainNote);gap(content,18);
        mp3Gain=button("MP3Gain",false);mp3Gain.setTag("song");mp3Gain.setOnClickListener(v->launch(new Intent(this,Mp3GainActivity.class).putExtra("source",source.getAbsolutePath()).putExtra("steps",mp3Steps).putExtra("undo",mp3Undo),MP3GAIN));content.addView(mp3Gain,new LinearLayout.LayoutParams(-1,dp(54)));gap(content,8);mp3Note=text("MP3専用・再エンコードせずに音量を変更します。",12,muted);content.addView(mp3Note);gap(content,18);
        TextView note=text("空欄にした項目は削除されます。\nMP3Gain以外では音声はそのまま。\n上書き・コピー保存を選べます。",12,muted);note.setLineSpacing(dp(4),1);content.addView(note);
        LinearLayout bottom=vertical();bottom.setPadding(0,dp(12),0,dp(12));progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);bottom.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));status=text("曲を選んでください",12,muted);status.setPadding(0,dp(8),0,dp(10));bottom.addView(status);save=button("保存する",true);save.setOnClickListener(v->startSave());bottom.addView(save,new LinearLayout.LayoutParams(-1,dp(52)));root.addView(bottom);setBusy(false,"曲を選んでください");preview();
    }
    private void confirmSwitch(){if(busy)return;if(dirty&&song!=null)new AlertDialog.Builder(this).setTitle("別の曲を開きますか？").setMessage("保存していない変更は破棄されます。").setNegativeButton("キャンセル",null).setPositiveButton("曲を選ぶ",(d,w)->pickSong()).show();else pickSong();}
    private void pickSong(){launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),OPEN);}
    private void launch(Intent intent,int code){try{startActivityForResult(intent,code);}catch(ActivityNotFoundException e){error(new IOException("ファイル選択アプリが見つかりません。"));}}
    private void setBusy(boolean b,String message){busy=b;songPicker.setEnabled(!b);songPicker.setAlpha(b?0.6f:1f);for(View v:controls)v.setEnabled(!b&&((v instanceof Button&&!"song".equals(v.getTag())) || song!=null));photo.setEnabled(!b&&song!=null);remove.setEnabled(!b&&song!=null&&picture!=null);save.setEnabled(!b&&song!=null);mp3Gain.setEnabled(!b&&song!=null&&"MP3".equals(song.format));progress.setVisibility(b?View.VISIBLE:View.GONE);status.setText(message);}
    private void fill(){mp3Steps=0;mp3Undo=false;mp3SourceHash="";updateMp3Note();for(int i=0;i<6;i++)fields[i].setText(song.values[i]);volume.setText(song.trackGain.replaceAll("(?i)\\s*dB$", ""));gainChanged=false;filename.setText(displayName);info.setText(song.format+"  ·  "+String.format(Locale.JAPAN,"%.1f MB",source.length()/1048576.0)+"  ·  タップして曲を変更");songPicker.setContentDescription("曲を変更。現在の曲は "+displayName);preview();dirty=false;}
    private void updateMp3Note(){if(mp3Note==null)return;mp3Note.setText(song!=null&&"FLAC".equals(song.format)?"MP3専用の機能です。FLACには使用できません。":mp3Undo?"保存時にMP3Gainを元に戻します。":mp3Steps!=0?String.format(Locale.JAPAN,"保存時に %+.1f dB を適用します。再エンコードは行いません。",mp3Steps*Mp3GainEngine.STEP_DB):"MP3専用・再エンコードせずに音量を変更します。");}
    private void applyMp3Result(Intent data){if(song==null||!"MP3".equals(song.format))return;mp3Steps=data.getIntExtra("steps",0);mp3Undo=data.getBooleanExtra("undo",false);mp3SourceHash=data.getStringExtra("audioHash");dirty=true;updateMp3Note();}
    private void adjustGain(int step){
        try{String n=TagEngine.normalizeGain(volume.getText().toString());java.math.BigDecimal gain=n.isEmpty()?java.math.BigDecimal.ZERO:new java.math.BigDecimal(n.replace(" dB",""));
            String value=TagEngine.normalizeGain(gain.add(new java.math.BigDecimal(step)).toPlainString());volume.setText(value.replace(" dB",""));volume.setSelection(volume.length());
        }catch(IOException e){volume.setError(e.getMessage());}
    }
    private void preview(){
        Bitmap bmp=null;if(picture!=null){BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(picture.data,0,picture.data.length,opts);int sample=1;while(opts.outWidth/sample>600||opts.outHeight/sample>600)sample*=2;opts.inJustDecodeBounds=false;opts.inSampleSize=sample;try{bmp=BitmapFactory.decodeByteArray(picture.data,0,picture.data.length,opts);}catch(OutOfMemoryError ignored){}}
        cover.setImageBitmap(bmp);if(picture==null){cover.setImageResource(R.drawable.ic_launcher);cover.setAlpha(0.25f);artInfo.setText("画像なし");}else{cover.setAlpha(1f);artInfo.setText(bmp==null?"画像を埋め込み済み（プレビュー非対応）":String.format(Locale.JAPAN,"%s  ·  %.0f KB",picture.mime.replace("image/", "").toUpperCase(Locale.ROOT),picture.data.length/1024.0));}if(remove!=null)remove.setEnabled(!busy&&song!=null&&picture!=null);
    }
    private String name(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "曲";}
    private boolean canWrite(Uri uri){
        if(checkUriPermission(uri,android.os.Process.myPid(),android.os.Process.myUid(),Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return false;
        try(Cursor c=getContentResolver().query(uri,new String[]{DocumentsContract.Document.COLUMN_FLAGS},null,null,null)){
            return c!=null&&c.moveToFirst()&&(c.getInt(0)&DocumentsContract.Document.FLAG_SUPPORTS_WRITE)!=0;
        }catch(Exception ignored){return false;}
    }
    private static byte[] readLimited(InputStream input,int max) throws IOException {if(input==null)throw new IOException("ファイルを開けませんでした。");try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IOException("写真が大きすぎます。32 MB以下の画像を選んでください。");out.write(b,0,n);}return out.toByteArray();}}
    private static void copy(InputStream input,OutputStream output) throws IOException {if(input==null||output==null)throw new IOException("ファイルを開けませんでした。");try(InputStream in=input;OutputStream out=output){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==MP3GAIN){if(result==RESULT_OK&&data!=null){if(busy)deferredMp3=data;else applyMp3Result(data);}return;}if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        if(request==OPEN){int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);try{getContentResolver().takePersistableUriPermission(uri,flags);}catch(SecurityException|IllegalArgumentException ignored){}setBusy(true,"曲の情報を読み込んでいます…");worker.execute(()->{File f=null;try{String n=name(uri);boolean writable=canWrite(uri);f=File.createTempFile("song-",".bin",getCacheDir());copy(getContentResolver().openInputStream(uri),new FileOutputStream(f));TagEngine.Song s=TagEngine.read(f);File loaded=f;
            runOnUiThread(()->{if(source!=null)source.delete();source=loaded;sourceUri=uri;sourceWritable=writable;song=s;picture=s.picture;displayName=n;artworkChanged=false;fill();setBusy(false,writable?"タグとジャケットを編集できます":"この曲はコピーとして保存できます");});
        }catch(Exception e){if(f!=null)f.delete();runOnUiThread(()->{setBusy(false,song==null?"曲を選んでください":"前の曲を編集中です");error(e);});}});}
        if(request==PHOTO){setBusy(true,"写真を読み込んでいます…");worker.execute(()->{try{byte[] raw=readLimited(getContentResolver().openInputStream(uri),32*1024*1024);BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(raw,0,raw.length,o);if(o.outWidth<=0||o.outHeight<=0)throw new IOException("この画像を読み込めません。JPEG・PNGなどを選んでください。");
            TagEngine.Picture p;
            int orientation=1;try{android.media.ExifInterface exif=new android.media.ExifInterface(new ByteArrayInputStream(raw));orientation=exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,1);}catch(IOException ignored){}
            boolean plain=("image/jpeg".equals(o.outMimeType)||"image/png".equals(o.outMimeType))&&raw.length<=10*1024*1024&&o.outWidth<=4096&&o.outHeight<=4096&&orientation==1;
            if(plain)p=new TagEngine.Picture(raw,o.outMimeType,o.outWidth,o.outHeight);
            else {int sample=1;while(o.outWidth/sample>2048||o.outHeight/sample>2048)sample*=2;o.inJustDecodeBounds=false;o.inSampleSize=sample;Bitmap bmp=BitmapFactory.decodeByteArray(raw,0,raw.length,o);if(bmp==null)throw new IOException("画像を変換できませんでした。");
                Matrix matrix=new Matrix();switch(orientation){case 2:matrix.setScale(-1,1);break;case 3:matrix.setRotate(180);break;case 4:matrix.setScale(1,-1);break;case 5:matrix.setRotate(90);matrix.postScale(-1,1);break;case 6:matrix.setRotate(90);break;case 7:matrix.setRotate(-90);matrix.postScale(-1,1);break;case 8:matrix.setRotate(-90);break;}
                if(!matrix.isIdentity()){Bitmap rotated=Bitmap.createBitmap(bmp,0,0,bmp.getWidth(),bmp.getHeight(),matrix,true);if(rotated!=bmp)bmp.recycle();bmp=rotated;}
                ByteArrayOutputStream out=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.JPEG,92,out);p=new TagEngine.Picture(out.toByteArray(),"image/jpeg",bmp.getWidth(),bmp.getHeight());bmp.recycle();}
            File pf=new File(getCacheDir(),"pending-cover");try(FileOutputStream out=new FileOutputStream(pf)){out.write(p.data);}runOnUiThread(()->{picture=p;artworkChanged=true;dirty=true;preview();setBusy(false,"ジャケットを選択しました");});
        }catch(Exception|OutOfMemoryError e){runOnUiThread(()->{setBusy(false,"写真を選び直してください");error(e);});}});}
        if(request==SAVE){if(busy&&song==null)deferredSave=uri;else export(uri,false);}
        if(request==RECOVER){if(busy&&song==null)deferredRecovery=uri;else recover(uri);}
    }
    private void startSave(){
        if(busy||song==null)return;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);
        new AlertDialog.Builder(this).setTitle("保存方法を選んでください")
            .setItems(new String[]{"元の曲に上書き", "編集したコピーを保存"},(d,w)->{
                if(w==1){saveCopy();return;}
                if(backup().exists()){offerRecovery();return;}
                if(sourceUri==null||!sourceWritable){
                    new AlertDialog.Builder(this).setTitle("この曲は上書きできません")
                        .setMessage("選んだ場所から書き込みの許可が得られませんでした。コピーを保存するか、端末内の曲を選び直してください。")
                        .setNegativeButton("キャンセル",null).setPositiveButton("コピーを保存",(x,y)->saveCopy()).show();return;
                }
                new AlertDialog.Builder(this).setTitle("元の曲に上書きしますか？")
                    .setMessage(displayName+(mp3Steps!=0||mp3Undo?"\n\nタグ・ジャケットとMP3Gainの設定を反映します。再エンコードは行いません。":"\n\nこのファイルのタグとジャケットを更新します。音声データはそのままです。"))
                    .setNegativeButton("キャンセル",null).setPositiveButton("上書き保存",(x,y)->export(sourceUri,true)).show();
            }).setNegativeButton("キャンセル",null).show();
    }
    private void saveCopy(){
        if(busy||song==null)return;
        String base=displayName.replaceAll("(?i)\\.(mp3|flac)$", "");if(base.isEmpty())base="曲";
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(song.format.equals("MP3")?"audio/mpeg":"audio/flac")
            .putExtra(Intent.EXTRA_TITLE,base+"_edited."+song.format.toLowerCase(Locale.ROOT));launch(i,SAVE);
    }
    private SaveEngine.Target target(Uri uri){return new SaveEngine.Target(){
        public InputStream openRead() throws IOException{return getContentResolver().openInputStream(uri);}
        public OutputStream openWrite() throws IOException{return getContentResolver().openOutputStream(uri,"wt");}
    };}
    private File backup(){return new File(getFilesDir(),"overwrite-original.bin");}
    private File backupName(){return new File(getFilesDir(),"overwrite-original-name.txt");}
    private void export(Uri uri,boolean overwrite){
        if(busy||song==null||source==null){error(new IOException("曲を開き直してから保存してください。"));return;}
        if(!overwrite&&uri.equals(sourceUri)){error(new IOException("元の曲への保存は「元の曲に上書き」を選んでください。"));return;}
        final String[] values=new String[6];for(int i=0;i<6;i++)values[i]=fields[i].getText().toString().trim();
        final String gain=volume.getText().toString();final boolean editGain=gainChanged;
        if(editGain){try{TagEngine.normalizeGain(gain);}catch(IOException e){volume.setError(e.getMessage());volume.requestFocus();return;}}
        final int frameSteps=mp3Steps;final boolean frameUndo=mp3Undo;final String frameHash=mp3SourceHash;final boolean editFrames=frameSteps!=0||frameUndo;
        final File original=source;final TagEngine.Song originalSong=song;final TagEngine.Picture art=picture;final boolean artChanged=artworkChanged;
        setBusy(true,overwrite?"上書き保存し、音声データを確認しています…":"コピーを保存し、音声データを確認しています…");
        worker.execute(()->{File result=null;File check=null;File gained=null;boolean committed=false;
            try{
                result=File.createTempFile("edited-",".bin",getCacheDir());
                if(editFrames){
                    if(frameHash==null||!frameHash.equals(Mp3GainEngine.inspect(original).audioHash))throw new IOException("解析した音声と一致しません。MP3Gainを設定し直してください。");
                    gained=File.createTempFile("mp3gain-",".mp3",getCacheDir());Mp3GainEngine.Prepared prepared=Mp3GainEngine.prepare(original,gained,frameSteps,frameUndo);
                    TagEngine.write(gained,result,TagEngine.read(gained),values,art,artChanged,gain,editGain,prepared.undo,true);
                    Mp3GainEngine.verifyTransform(original,result,prepared.appliedSteps);
                }else TagEngine.write(original,result,originalSong,values,art,artChanged,gain,editGain);
                TagEngine.Song updated=overwrite?TagEngine.read(result):null;
                check=File.createTempFile("check-",".bin",getCacheDir());
                if(overwrite){
                    if(backup().exists())throw new IOException("保管中の元データを先に取り出してください。");
                    try(FileOutputStream out=new FileOutputStream(backupName())){out.write(displayName.getBytes("UTF-8"));out.getFD().sync();}
                    SaveEngine.overwrite(original,result,target(uri),backup(),check);
                    committed=true;backupName().delete();
                }else SaveEngine.copyVerified(result,target(uri),check);
                String n=name(uri);final File savedSource=result;
                runOnUiThread(()->{
                    if(overwrite){source=savedSource;song=updated;picture=updated.picture;artworkChanged=false;fill();original.delete();}
                    dirty=false;setBusy(false,(overwrite?"上書きしました：":"コピーを保存しました：")+n);
                    new AlertDialog.Builder(this).setTitle(overwrite?"上書きできました 🎵":"コピーを保存できました 🎵")
                        .setMessage((editFrames?"タグ・ジャケット・ReplayGainを保持し、MP3Gainを反映しました。音量値と必要なCRC以外の音声データが変わっていないことを確認しました。再エンコードは行っていません。":"タグ・ジャケット・音量補正を保存しました。音声データが元の曲と同じことも確認しました。")+"\n\n"+n).setPositiveButton("OK",null).show();
                });
            }catch(Exception e){
                if(!overwrite){try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}}
                if(overwrite&&!backup().exists())backupName().delete();
                runOnUiThread(()->{setBusy(false,"保存できませんでした。編集内容は残っています");if(e instanceof SaveEngine.RecoveryRequired)offerRecovery();else error(e);});
            }finally{
                if(result!=null&&!(overwrite&&committed))result.delete();if(check!=null)check.delete();if(gained!=null)gained.delete();
            }
        });
    }
    private void offerRecovery(){
        if(isFinishing()||isDestroyed()||!backup().exists())return;
        new AlertDialog.Builder(this).setTitle("元データを保管しています")
            .setMessage("上書きが中断されたか、保存先の確認・復元ができませんでした。元の曲を別のファイルとして取り出せます。保管中は新しい上書き保存を停止します。")
            .setNegativeButton("あとで",null).setPositiveButton("元データを保存",(d,w)->{
                String n="元の曲";try{n=new String(readLimited(new FileInputStream(backupName()),65536),"UTF-8");}catch(Exception ignored){}
                String format="MP3";try{format=TagEngine.read(backup()).format;}catch(Exception ignored){}
                String base=n.replaceAll("(?i)\\.(mp3|flac)$", "");
                launch(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(format.equals("MP3")?"audio/mpeg":"audio/flac")
                    .putExtra(Intent.EXTRA_TITLE,base+"_recovered."+format.toLowerCase(Locale.ROOT)),RECOVER);
            }).show();
    }
    private void recover(Uri uri){
        if(busy)return;
        if(uri.equals(sourceUri)){error(new IOException("元データは別のファイルとして保存してください。"));return;}
        setBusy(true,"元データを保存しています…");
        worker.execute(()->{File check=null;try{
            check=File.createTempFile("recover-",".bin",getCacheDir());SaveEngine.copyVerified(backup(),target(uri),check);
            backup().delete();backupName().delete();String n=name(uri);
            runOnUiThread(()->{setBusy(false,"元データを保存しました："+n);new AlertDialog.Builder(this).setTitle("元データを保存しました")
                .setMessage(n+"\n\n編集を続ける場合は、保存した元の曲を選び直してください。")
                .setPositiveButton("OK",null).show();});
        }catch(Exception e){try{DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}runOnUiThread(()->{setBusy(false,"元データは引き続き保管しています");error(e);});}
        finally{if(check!=null)check.delete();}});
    }
    private void error(Throwable e){if(isFinishing()||isDestroyed())return;String message=e.getMessage();if(message==null||message.isEmpty())message="処理できませんでした。ファイルを選び直してください。";new AlertDialog.Builder(this).setTitle("処理できませんでした").setMessage(message).setPositiveButton("OK",null).show();}
    @Override public void onBackPressed(){if(busy){Toast.makeText(this,"処理が完了するまでお待ちください",Toast.LENGTH_SHORT).show();return;}if(dirty&&song!=null)new AlertDialog.Builder(this).setTitle("編集を終了しますか？").setMessage("保存していない変更は破棄されます。").setNegativeButton("編集を続ける",null).setPositiveButton("終了",(d,w)->finish()).show();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);if(source!=null){b.putString("source",source.getAbsolutePath());b.putString("name",displayName);if(sourceUri!=null)b.putString("sourceUri",sourceUri.toString());b.putBoolean("sourceWritable",sourceWritable);String[] vals=new String[6];for(int i=0;i<6;i++)vals[i]=fields[i].getText().toString();b.putStringArray("values",vals);b.putBoolean("dirty",dirty);b.putString("volume",volume.getText().toString());b.putBoolean("gainChanged",gainChanged);b.putInt("mp3Steps",mp3Steps);b.putBoolean("mp3Undo",mp3Undo);b.putString("mp3Hash",mp3SourceHash);b.putBoolean("artChanged",artworkChanged);if(artworkChanged&&picture!=null){b.putString("picture",new File(getCacheDir(),"pending-cover").getAbsolutePath());b.putString("mime",picture.mime);b.putInt("width",picture.width);b.putInt("height",picture.height);}}}
    @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c); // Keep edits during rotation and theme changes. Refresh colors on next launch.
    }
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
