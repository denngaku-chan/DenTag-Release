package jp.dengaku.dentag;

import java.io.*;
import java.security.MessageDigest;
import java.util.Arrays;

/** Verified document writes, with a durable original retained until overwrite succeeds. */
public final class SaveEngine {
    public interface Target {
        InputStream openRead() throws IOException;
        OutputStream openWrite() throws IOException;
    }
    public static final class RecoveryRequired extends IOException {
        private static final long serialVersionUID=1L;
        public RecoveryRequired(Throwable cause) {
            super("上書きに失敗し、元の曲への復元もできませんでした。元データはアプリ内に保管しています。「元データを保存」で取り出してください。", cause);
        }
    }
    public static void copy(InputStream input, OutputStream output) throws IOException {
        if(input==null || output==null) {
            if(input!=null)input.close();if(output!=null)output.close();
            throw new IOException("ファイルを開けませんでした。");
        }
        try(InputStream in=input;OutputStream out=output) {
            byte[] b=new byte[65536];int n;
            while((n=in.read(b))!=-1)out.write(b,0,n);
        }
    }
    public static byte[] hash(File f) throws IOException {
        final MessageDigest d;
        try{d=MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new IOException(e);}
        try(InputStream in=new FileInputStream(f)) {
            byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)d.update(b,0,n);
        }
        return d.digest();
    }
    private static void verify(File expected, Target target, File check) throws IOException {
        copy(target.openRead(),new FileOutputStream(check));
        if(!Arrays.equals(hash(expected),hash(check)))throw new IOException("保存先のファイルを確認できませんでした。");
    }
    public static void copyVerified(File edited, Target target, File check) throws IOException {
        // Open the input first so an unavailable local file never truncates the target.
        try(InputStream in=new FileInputStream(edited)) { copy(in,target.openWrite()); }
        verify(edited,target,check);
    }
    public static void overwrite(File original, File edited, Target target, File backup, File check) throws IOException {
        if(backup.exists())throw new IOException("保管中の元データを先に「元データを保存」で取り出してください。");
        // Detect edits made by another app since this song was opened.
        copy(target.openRead(),new FileOutputStream(check));
        if(!Arrays.equals(hash(original),hash(check)))throw new IOException("元の曲が別の場所で変更されています。曲を選び直すか、編集したコピーを保存してください。");
        File staging=new File(backup.getPath()+".pending");
        try {
            try(InputStream in=new FileInputStream(check);FileOutputStream out=new FileOutputStream(staging)) {
                byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                out.getFD().sync();
            }
            if(!Arrays.equals(hash(original),hash(staging))||!staging.renameTo(backup))throw new IOException("元データを退避できませんでした。");
        }catch(IOException|RuntimeException e){staging.delete();throw e;}
        boolean touched=false;
        try {
            try(InputStream in=new FileInputStream(edited)) {
                // Treat even an open failure as potentially destructive: providers can truncate then throw.
                touched=true;
                copy(in,target.openWrite());
            }
            verify(edited,target,check);
        }catch(IOException|RuntimeException e) {
            if(touched) {
                try{copyVerified(backup,target,check);}
                catch(Exception restore){e.addSuppressed(restore);throw new RecoveryRequired(e);}
            }
            backup.delete();
            throw new IOException(touched?"上書きできませんでした。元の曲に戻しました。編集内容は残っています。\n"+e.getMessage():e.getMessage(),e);
        }
        backup.delete();
    }
    private SaveEngine() {}
}
