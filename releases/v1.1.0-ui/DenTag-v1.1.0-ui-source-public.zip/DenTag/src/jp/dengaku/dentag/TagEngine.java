package jp.dengaku.dentag;

import java.io.*;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.*;

/** Metadata-only editor. Audio is copied as bytes and verified before export. */
public final class TagEngine {
    public static final String[] KEYS = {"TITLE", "ARTIST", "ALBUM", "TRACKNUMBER", "DATE", "GENRE"};
    private static final String[] IDS = {"TIT2", "TPE1", "TALB", "TRCK", "TDRC", "TCON"};
    private static final String[] IDS2 = {"TT2", "TP1", "TAL", "TRK", "TYE", "TCO"};
    private static final int LIMIT = 32 * 1024 * 1024;
    private static final String GAIN_KEY="REPLAYGAIN_TRACK_GAIN";
    public static final class Picture {
        public byte[] data; public String mime; public int width, height, depth = 24;
        public Picture(byte[] d, String m, int w, int h) { data=d; mime=m; width=w; height=h; }
    }
    private static final class Frame {
        String id; byte[] data; int flags;
        Frame(String i, byte[] d, int f) {id=i;data=d;flags=f;}
    }
    private static final class Block {
        int type; byte[] data;
        Block(int t, byte[] d) {type=t;data=d;}
    }
    public static final class Song {
        public String format;
        public String[] values = {"", "", "", "", "", ""};
        public String trackGain="";
        public String mp3GainUndo="";
        public Picture picture;
        public long audioStart, audioEnd;
        int version=3;
        List<Frame> frames=new ArrayList<>();
        List<Block> blocks=new ArrayList<>();
        List<String> comments=new ArrayList<>();
        byte[] vendor="DenTag".getBytes(Charset.forName("UTF-8"));
    }
    private static IOException invalid(String s) {return new IOException(s);}
    private static int u(byte b) {return b & 255;}
    private static String str(byte[] b, int p, int n, String c) throws IOException {
        if(p<0 || n<0 || p+n>b.length) throw invalid("タグの長さが正しくありません。");
        return new String(b,p,n,Charset.forName(c));
    }
    private static int be(byte[] b,int p,int n) throws IOException {
        if(p<0 || n<0 || p+n>b.length) throw invalid("タグが途中で切れています。");
        long v=0;for(int i=0;i<n;i++) v=(v<<8)|u(b[p+i]);
        if(v>Integer.MAX_VALUE) throw invalid("タグのサイズが大きすぎます。");return (int)v;
    }
    private static int sync(byte[] b,int p) throws IOException {
        if(p+4>b.length) throw invalid("タグが途中で切れています。");
        int v=0;for(int i=0;i<4;i++){if(u(b[p+i])>127)throw invalid("ID3のサイズが正しくありません。");v=(v<<7)|u(b[p+i]);}return v;
    }
    private static void number(OutputStream o,int v,int n,boolean syn) throws IOException {
        for(int i=n-1;i>=0;i--)o.write((v >>> (i*(syn?7:8))) & (syn?127:255));
    }
    private static int le(byte[] b,int p) throws IOException {
        if(p<0 || p+4>b.length)throw invalid("FLACタグが途中で切れています。");
        long v=0;for(int i=3;i>=0;i--)v=(v<<8)|u(b[p+i]);
        if(v>LIMIT)throw invalid("FLACタグのサイズが大きすぎます。");return (int)v;
    }
    private static void little(OutputStream o,int v) throws IOException {for(int i=0;i<4;i++)o.write(v >>> (8*i) & 255);}
    private static byte[] bytes(RandomAccessFile r,int n) throws IOException {
        if(n<0 || n>LIMIT || r.getFilePointer()+n>r.length())throw invalid("タグが大きすぎるか、破損しています。");
        byte[] b=new byte[n];r.readFully(b);return b;
    }
    private static byte[] deunsync(byte[] b) {
        ByteArrayOutputStream o=new ByteArrayOutputStream();
        for(int i=0;i<b.length;i++){o.write(b[i]);if(u(b[i])==255 && i+1<b.length && b[i+1]==0)i++;}return o.toByteArray();
    }
    public static Song read(File file) throws IOException {
        try(RandomAccessFile r=new RandomAccessFile(file,"r")) {
            Song s=new Song();s.audioEnd=r.length();
            if(r.length()<4)throw invalid("曲ファイルが短すぎます。");
            byte[] magic=bytes(r,4);
            if("fLaC".equals(str(magic,0,4,"ISO-8859-1")))readFlac(r,s);
            else {r.seek(0);readMp3(r,s);}
            return s;
        }
    }
    private static String text(Frame f,int v) throws IOException {
        byte[] b=decoded(f,v);if(b.length<1)return "";
        int enc=u(b[0]);if(enc>3)throw invalid("この文字コードのタグには対応していません。");
        String c=new String[]{"ISO-8859-1","UTF-16","UTF-16BE","UTF-8"}[enc];
        String t=str(b,1,b.length-1,c);int end=t.indexOf('\0');return (end>=0?t.substring(0,end):t).trim();
    }
    private static byte[] decoded(Frame f,int v) throws IOException {
        if((v==3 && (f.flags&0xC0)!=0)||(v==4 && (f.flags&0x0C)!=0))
            throw invalid("圧縮・暗号化されたタグには対応していません。");
        byte[] b=f.data;if(v==4 && (f.flags&2)!=0)b=deunsync(b);
        int p=0;if((v==3&&(f.flags&0x20)!=0)||(v==4&&(f.flags&0x40)!=0))p++;
        if(v==4&&(f.flags&1)!=0)p+=4;
        if(p>b.length)throw invalid("タグの付加情報が破損しています。");return Arrays.copyOfRange(b,p,b.length);
    }
    private static String[] userText(Frame f,int v) {
        if(!f.id.equals(v==2?"TXX":"TXXX"))return null;
        try{
            byte[] b=decoded(f,v);if(b.length<2||u(b[0])>3)return null;
            String t=str(b,1,b.length-1,new String[]{"ISO-8859-1","UTF-16","UTF-16BE","UTF-8"}[u(b[0])]);
            int end=t.indexOf('\0');if(end<0)return null;
            String value=t.substring(end+1);if(value.startsWith("\uFEFF"))value=value.substring(1);
            end=value.indexOf('\0');if(end>=0)value=value.substring(0,end);
            return new String[]{t.substring(0,t.indexOf('\0')),value.trim()};
        }catch(IOException ignored){return null;}
    }
    private static boolean customFrame(Frame f,int v,String key){String[] t=userText(f,v);return t!=null&&key.equalsIgnoreCase(t[0]);}
    private static boolean gainFrame(Frame f,int v){return customFrame(f,v,GAIN_KEY);}
    public static String normalizeGain(String value) throws IOException {
        if(value==null)throw invalid("音量補正の値が正しくありません。");
        String n=value.trim().replace('\u2212','-').replace('\uFF0B','+').replace('\uFF0D','-').replaceAll("(?i)\\s*dB$", "").trim();
        if(n.isEmpty())return "";
        if(n.length()>30||!n.matches("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)"))throw invalid("音量補正は数値で入力してください（例：-3.0、+3.0）。");
        java.math.BigDecimal gain=new java.math.BigDecimal(n);
        if(gain.abs().compareTo(new java.math.BigDecimal("60"))>0)throw invalid("音量補正は-60〜+60 dBで入力してください。");
        gain=gain.setScale(2,java.math.RoundingMode.HALF_UP);
        return (gain.signum()>=0?"+":"")+gain.toPlainString()+" dB";
    }
    private static void readMp3(RandomAccessFile r,Song s) throws IOException {
        s.format="MP3";
        byte[] h=bytes(r,(int)Math.min(10,r.length()));
        if(h.length==10 && "ID3".equals(str(h,0,3,"ISO-8859-1"))) {
            int v=u(h[3]),flags=u(h[5]);s.version=v;
            if(v<2 || v>4 || h[4]!=0)throw invalid("このID3バージョンには対応していません。");
            if((flags & (v==2?0x7F:v==3?0x1F:0x0F))!=0)throw invalid("特殊なID3タグには対応していません。");
            int size=sync(h,6);byte[] b=bytes(r,size);s.audioStart=10L+size;
            if(v==4&&(flags&16)!=0){byte[] footer=bytes(r,10);if(!"3DI".equals(str(footer,0,3,"ISO-8859-1")))throw invalid("ID3フッターが破損しています。");s.audioStart+=10;}
            if(v<4&&(flags&128)!=0)b=deunsync(b);
            int p=0;
            if((flags&64)!=0){p=v==3?be(b,0,4)+4:sync(b,0);if(p<(v==3?10:6)||p>b.length)throw invalid("ID3拡張ヘッダーが破損しています。");}
            int head=v==2?6:10;
            while(p<b.length && b[p]!=0){
                if(p+head>b.length)throw invalid("ID3フレームが途中で切れています。");
                String id=str(b,p,v==2?3:4,"ISO-8859-1");if(!id.matches("[A-Z0-9]{"+(v==2?3:4)+"}"))throw invalid("ID3フレームが破損しています。");
                int n=v==2?be(b,p+3,3):v==3?be(b,p+4,4):sync(b,p+4);
                int f=v==2?0:be(b,p+8,2);
                if(n>LIMIT || n<=0 || (long)p+head+n>b.length)throw invalid("ID3フレームの長さが正しくありません。");
                if(v==4&&(flags&128)!=0)f|=2;
                Frame frame=new Frame(id,Arrays.copyOfRange(b,p+head,p+head+n),f);s.frames.add(frame);
                String[] custom=userText(frame,v);if(custom!=null&&GAIN_KEY.equalsIgnoreCase(custom[0])&&s.trackGain.isEmpty())s.trackGain=custom[1];
                if(custom!=null&&Mp3GainEngine.UNDO_KEY.equalsIgnoreCase(custom[0])){if(!s.mp3GainUndo.isEmpty()&&!s.mp3GainUndo.equals(custom[1]))throw invalid("MP3GainのUndo情報が重複しています。");s.mp3GainUndo=custom[1];}
                for(int k=0;k<KEYS.length;k++)if(id.equals(v==2?IDS2[k]:(k==4&&v==3?"TYER":IDS[k])) || (k==4&&id.equals("TYER"))){if(s.values[k].isEmpty())s.values[k]=text(frame,v);}
                if(id.equals(v==2?"PIC":"APIC")) {Picture pic=id3Picture(decoded(frame,v),v);if(pic!=null&&(s.picture==null || pictureType(decoded(frame,v),v)==3))s.picture=pic;}
                p+=head+n;
            }
            for(;p<b.length;p++)if(b[p]!=0)throw invalid("ID3パディングが破損しています。");
        }
        if(r.length()>=128){r.seek(r.length()-128);byte[] tail=bytes(r,128);
            if("TAG".equals(str(tail,0,3,"ISO-8859-1"))){
                String[] legacy={legacy(tail,3,30),legacy(tail,33,30),legacy(tail,63,30),tail[125]==0&&tail[126]!=0?Integer.toString(u(tail[126])):"",legacy(tail,93,4),""};
                for(int i=0;i<6;i++)if(s.values[i].isEmpty())s.values[i]=legacy[i];
                if(s.values[5].isEmpty() && u(tail[127])!=255)s.values[5]=u(tail[127])<GENRES.length?GENRES[u(tail[127])]:"("+u(tail[127])+")";
                String comment=legacy(tail,97,tail[125]==0?28:30);
                boolean exists=false;for(Frame f:s.frames)if(f.id.equals("COMM")||f.id.equals("COM"))exists=true;
                if(!exists&&!comment.isEmpty()) {ByteArrayOutputStream c=new ByteArrayOutputStream();c.write(0);c.write("eng".getBytes("ISO-8859-1"));c.write(0);c.write(comment.getBytes("ISO-8859-1"));s.frames.add(new Frame(s.version==2?"COM":"COMM",c.toByteArray(),0));}
                s.audioEnd-=128;
            }
        }
        if(s.audioEnd<=s.audioStart)throw invalid("MP3の音声部分がありません。");
        r.seek(s.audioStart);byte[] probe=bytes(r,(int)Math.min(8192,s.audioEnd-s.audioStart));boolean found=false;
        for(int i=0;i+3<probe.length;i++){int b1=u(probe[i+1]),b2=u(probe[i+2]);if(u(probe[i])==255&&(b1&0xE0)==0xE0&&(b1&0x18)!=8&&(b1&6)==2&&(b2&0xF0)!=0xF0&&(b2&0x0C)!=0x0C){found=true;break;}}
        if(!found)throw invalid("MP3・FLACの曲ファイルを選んでください。");
    }
    private static String legacy(byte[] b,int p,int n) throws IOException {String t=str(b,p,n,"ISO-8859-1");int z=t.indexOf('\0');return (z<0?t:t.substring(0,z)).trim();}
    private static int zero(byte[] b,int p,int enc) throws IOException {
        if(enc==1||enc==2){for(int i=p;i+1<b.length;i+=2)if(b[i]==0&&b[i+1]==0)return i+2;}
        else for(int i=p;i<b.length;i++)if(b[i]==0)return i+1;
        throw invalid("画像タグの区切りが見つかりません。");
    }
    private static int pictureType(byte[] b,int v) throws IOException {int p=v==2?4:zero(b,1,0);if(p>=b.length)throw invalid("画像タグが破損しています。");return u(b[p]);}
    private static Picture id3Picture(byte[] b,int v) throws IOException {
        if(b.length<6)throw invalid("画像タグが短すぎます。");int enc=u(b[0]);if(enc>3)throw invalid("画像の説明文の文字コードに対応していません。");
        String mime;int p;
        if(v==2){String fmt=str(b,1,3,"ISO-8859-1");mime=fmt.equals("PNG")?"image/png":fmt.equals("JPG")?"image/jpeg":fmt;p=4;}
        else {p=zero(b,1,0);mime=str(b,1,p-2,"ISO-8859-1");}
        p=zero(b,p+1,enc);if(mime.equals("-->"))return null;
        return new Picture(Arrays.copyOfRange(b,p,b.length),mime,0,0);
    }
    private static void readFlac(RandomAccessFile r,Song s) throws IOException {
        s.format="FLAC";boolean last=false;int total=0;boolean commentSeen=false;
        while(!last){byte[] h=bytes(r,4);last=(u(h[0])&128)!=0;int type=u(h[0])&127;int n=be(h,1,3);total+=n;
            if(total>LIMIT)throw invalid("FLACのタグが大きすぎます。");byte[] b=bytes(r,n);
            if(s.blocks.isEmpty()&&(type!=0||n!=34))throw invalid("FLACのSTREAMINFOが破損しています。");
            if(type==127 || (type==0&&!s.blocks.isEmpty()))throw invalid("FLACのメタデータが破損しています。");
            s.blocks.add(new Block(type,b));
            if(type==4){if(commentSeen)throw invalid("複数のFLACコメントブロックには対応していません。");commentSeen=true;readComments(b,s);}
            if(type==6){Picture pic=flacPicture(b);if(s.picture==null||be(b,0,4)==3)s.picture=pic;}
        }
        s.audioStart=r.getFilePointer();if(s.audioStart>=s.audioEnd)throw invalid("FLACの音声部分がありません。");
        for(String c:s.comments){int e=c.indexOf('=');if(e<0)continue;String k=c.substring(0,e).toUpperCase(Locale.ROOT);for(int i=0;i<KEYS.length;i++)if(k.equals(KEYS[i])||(i==4&&k.equals("YEAR")))if(s.values[i].isEmpty())s.values[i]=c.substring(e+1);}
        for(String c:s.comments){int e=c.indexOf('=');if(e>=0&&GAIN_KEY.equalsIgnoreCase(c.substring(0,e))&&s.trackGain.isEmpty())s.trackGain=c.substring(e+1).trim();}
    }
    private static void readComments(byte[] b,Song s) throws IOException {
        int n=le(b,0),p=4;if((long)p+n>b.length)throw invalid("FLACコメントが破損しています。");s.vendor=Arrays.copyOfRange(b,p,p+n);p+=n;
        int count=le(b,p);p+=4;if(count>(b.length-p)/4)throw invalid("FLACコメント数が正しくありません。");
        for(int i=0;i<count;i++){n=le(b,p);p+=4;s.comments.add(str(b,p,n,"UTF-8"));p+=n;}if(p!=b.length)throw invalid("FLACコメントの長さが正しくありません。");
    }
    private static Picture flacPicture(byte[] b) throws IOException {
        int p=4,n=be(b,p,4);p+=4;String mime=str(b,p,n,"ISO-8859-1");p+=n;n=be(b,p,4);p+=4;
        if((long)p+n+20>b.length)throw invalid("FLAC画像タグが破損しています。");p+=n;int w=be(b,p,4),h=be(b,p+4,4),depth=be(b,p+8,4);p+=16;n=be(b,p,4);p+=4;
        if((long)p+n!=b.length)throw invalid("FLAC画像の長さが正しくありません。");Picture pic=new Picture(Arrays.copyOfRange(b,p,p+n),mime,w,h);pic.depth=depth;return pic;
    }
    private static boolean target(String id,int v) {for(String x:v==2?IDS2:IDS)if(x.equals(id))return true;return id.equals("TYER");}
    public static void write(File source,File destination,Song s,String[] values,Picture picture,boolean artworkChanged) throws IOException {
        write(source,destination,s,values,picture,artworkChanged,s.trackGain,false);
    }
    public static void write(File source,File destination,Song s,String[] values,Picture picture,boolean artworkChanged,String trackGain,boolean gainChanged) throws IOException {
        write(source,destination,s,values,picture,artworkChanged,trackGain,gainChanged,s.mp3GainUndo,false);
    }
    public static void write(File source,File destination,Song s,String[] values,Picture picture,boolean artworkChanged,String trackGain,boolean gainChanged,String undo,boolean undoChanged) throws IOException {
        if(undoChanged&&!"MP3".equals(s.format))throw invalid("MP3GainはMP3専用です。");
        if(undoChanged&&!undo.isEmpty())Mp3GainEngine.Undo.parse(undo);
        if(source.getCanonicalFile().equals(destination.getCanonicalFile()))throw invalid("元の曲とは別のファイルに保存してください。");
        if(values.length!=6)throw invalid("入力項目が正しくありません。");
        for(String t:values)if(t==null||t.indexOf('\0')>=0||t.length()>16384)throw invalid("タグの文字数が多すぎるか、使えない文字が含まれています。");
        if("MP3".equals(s.format)&&s.version<4&&!values[4].trim().isEmpty()&&!values[4].trim().matches("[0-9]{4}"))throw invalid("このMP3の発売年は4桁で入力してください（例：2026）。");
        String gain=gainChanged?normalizeGain(trackGain):s.trackGain;
        try(RandomAccessFile r=new RandomAccessFile(source,"r");OutputStream out=new BufferedOutputStream(new FileOutputStream(destination))){
            if("MP3".equals(s.format))writeMp3(out,s,values,picture,artworkChanged,gain,gainChanged,undo,undoChanged);else writeFlac(out,s,values,picture,artworkChanged,gain,gainChanged);
            r.seek(s.audioStart);long remaining=s.audioEnd-s.audioStart;byte[] buf=new byte[65536];while(remaining>0){int n=r.read(buf,0,(int)Math.min(buf.length,remaining));if(n<0)throw invalid("元の曲が途中で切れています。");out.write(buf,0,n);remaining-=n;}
        }
        Song verify=read(destination);
        if(undoChanged&&!undo.equals(verify.mp3GainUndo))throw invalid("保存したMP3GainのUndo情報を確認できませんでした。");
        if(gainChanged&&!gain.equals(verify.trackGain))throw invalid("保存した音量補正タグを確認できませんでした。");
        for(int i=0;i<6;i++)if(!values[i].trim().equals(verify.values[i]))throw invalid("保存したタグを確認できませんでした。");
        if(artworkChanged && ((picture==null)!=(verify.picture==null) || (picture!=null&&!Arrays.equals(picture.data,verify.picture.data))))throw invalid("保存したジャケットを確認できませんでした。");
        if(!Arrays.equals(audioHash(source,s),audioHash(destination,verify)))throw invalid("音声データの確認に失敗しました。");
    }
    public static byte[] audioHash(File f,Song s) throws IOException {
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");try(RandomAccessFile r=new RandomAccessFile(f,"r")){r.seek(s.audioStart);long n=s.audioEnd-s.audioStart;byte[] b=new byte[65536];while(n>0){int k=r.read(b,0,(int)Math.min(n,b.length));if(k<0)throw invalid("音声部分が途中で切れています。");md.update(b,0,k);n-=k;}}return md.digest();}catch(java.security.NoSuchAlgorithmException e){throw new IOException(e);}
    }
    private static void frame(OutputStream out,Frame f,int v) throws IOException {
        if(f.data.length>0xFFFFFF && v==2)throw invalid("ID3v2.2に保存する画像が大きすぎます。");
        out.write(f.id.getBytes("ISO-8859-1"));number(out,f.data.length,v==2?3:4,v==4);if(v!=2)number(out,f.flags,2,false);out.write(f.data);
    }
    private static void writeMp3(OutputStream out,Song s,String[] values,Picture pic,boolean artChanged,String gain,boolean gainChanged,String undo,boolean undoChanged) throws IOException {
        ByteArrayOutputStream body=new ByteArrayOutputStream();int v=s.version;String apic=v==2?"PIC":"APIC";
        for(Frame f:s.frames)if(!target(f.id,v)&&!(artChanged&&f.id.equals(apic))&&!(gainChanged&&gainFrame(f,v))&&!(undoChanged&&customFrame(f,v,Mp3GainEngine.UNDO_KEY))&&!(v==3&&(f.flags&0x8000)!=0)&&!(v==4&&(f.flags&0x4000)!=0))frame(body,f,v);
        if(gainChanged&&!gain.isEmpty()){
            ByteArrayOutputStream b=new ByteArrayOutputStream();b.write(0);b.write(GAIN_KEY.getBytes("ISO-8859-1"));b.write(0);b.write(gain.getBytes("ISO-8859-1"));
            frame(body,new Frame(v==2?"TXX":"TXXX",b.toByteArray(),0),v);
        }
        if(undoChanged&&!undo.isEmpty()){
            ByteArrayOutputStream b=new ByteArrayOutputStream();b.write(0);b.write(Mp3GainEngine.UNDO_KEY.getBytes("ISO-8859-1"));b.write(0);b.write(undo.getBytes("ISO-8859-1"));frame(body,new Frame(v==2?"TXX":"TXXX",b.toByteArray(),0),v);
        }
        for(int i=0;i<6;i++)if(!values[i].trim().isEmpty()){
            ByteArrayOutputStream b=new ByteArrayOutputStream();b.write(v==4?3:1);b.write(values[i].trim().getBytes(v==4?"UTF-8":"UTF-16"));
            frame(body,new Frame(v==2?IDS2[i]:i==4&&v==3?"TYER":IDS[i],b.toByteArray(),0),v);
        }
        if(artChanged&&pic!=null){ByteArrayOutputStream b=new ByteArrayOutputStream();b.write(0);b.write((v==2?(pic.mime.equals("image/png")?"PNG":"JPG"):pic.mime).getBytes("ISO-8859-1"));if(v!=2)b.write(0);b.write(3);b.write(0);b.write(pic.data);frame(body,new Frame(apic,b.toByteArray(),0),v);}
        body.write(new byte[1024]);if(body.size()>LIMIT)throw invalid("保存するタグが大きすぎます。");out.write(new byte[]{'I','D','3',(byte)v,0,0});number(out,body.size(),4,true);body.writeTo(out);
    }
    private static boolean managed(String c){int p=c.indexOf('=');if(p<0)return false;String k=c.substring(0,p).toUpperCase(Locale.ROOT);for(String t:KEYS)if(t.equals(k))return true;return k.equals("YEAR");}
    private static void writeFlac(OutputStream out,Song s,String[] values,Picture pic,boolean artChanged,String gain,boolean gainChanged) throws IOException {
        List<Block> blocks=new ArrayList<>();for(Block b:s.blocks)if(b.type!=1&&b.type!=4&&!(artChanged&&b.type==6))blocks.add(b);
        List<String> comments=new ArrayList<>();for(String c:s.comments)if(!managed(c)&&!(gainChanged&&c.toUpperCase(Locale.ROOT).startsWith(GAIN_KEY+"="))&&!(artChanged&&(c.toUpperCase(Locale.ROOT).startsWith("METADATA_BLOCK_PICTURE=")||c.toUpperCase(Locale.ROOT).startsWith("COVERART=")||c.toUpperCase(Locale.ROOT).startsWith("COVERARTMIME="))))comments.add(c);
        if(gainChanged&&!gain.isEmpty())comments.add(GAIN_KEY+"="+gain);
        for(int i=0;i<6;i++)if(!values[i].trim().isEmpty())comments.add(KEYS[i]+"="+values[i].trim());
        ByteArrayOutputStream b=new ByteArrayOutputStream();little(b,s.vendor.length);b.write(s.vendor);little(b,comments.size());for(String c:comments){byte[] d=c.getBytes("UTF-8");little(b,d.length);b.write(d);}blocks.add(new Block(4,b.toByteArray()));
        if(artChanged&&pic!=null){b=new ByteArrayOutputStream();number(b,3,4,false);byte[] mime=pic.mime.getBytes("ISO-8859-1");number(b,mime.length,4,false);b.write(mime);number(b,0,4,false);number(b,pic.width,4,false);number(b,pic.height,4,false);number(b,pic.depth,4,false);number(b,0,4,false);number(b,pic.data.length,4,false);b.write(pic.data);blocks.add(new Block(6,b.toByteArray()));}
        blocks.add(new Block(1,new byte[1024]));out.write("fLaC".getBytes("ISO-8859-1"));int total=0;
        for(int i=0;i<blocks.size();i++){Block x=blocks.get(i);total+=x.data.length;if(x.data.length>0xFFFFFF||total>LIMIT)throw invalid("保存するFLACタグが大きすぎます。");out.write(x.type|(i==blocks.size()-1?128:0));number(out,x.data.length,3,false);out.write(x.data);}
    }
    private static final String[] GENRES = ("Blues|Classic Rock|Country|Dance|Disco|Funk|Grunge|Hip-Hop|Jazz|Metal|New Age|Oldies|Other|Pop|R&B|Rap|Reggae|Rock|Techno|Industrial|Alternative|Ska|Death Metal|Pranks|Soundtrack|Euro-Techno|Ambient|Trip-Hop|Vocal|Jazz+Funk|Fusion|Trance|Classical|Instrumental|Acid|House|Game|Sound Clip|Gospel|Noise|AlternRock|Bass|Soul|Punk|Space|Meditative|Instrumental Pop|Instrumental Rock|Ethnic|Gothic|Darkwave|Techno-Industrial|Electronic|Pop-Folk|Eurodance|Dream|Southern Rock|Comedy|Cult|Gangsta|Top 40|Christian Rap|Pop/Funk|Jungle|Native American|Cabaret|New Wave|Psychadelic|Rave|Showtunes|Trailer|Lo-Fi|Tribal|Acid Punk|Acid Jazz|Polka|Retro|Musical|Rock & Roll|Hard Rock").split("\\|");
}
