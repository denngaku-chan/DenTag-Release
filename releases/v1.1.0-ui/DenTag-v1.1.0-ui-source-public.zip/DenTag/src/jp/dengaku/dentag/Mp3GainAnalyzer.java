package jp.dengaku.dentag;

import android.media.*;
import java.io.*;
import java.nio.*;

/** Decodes only for measurement. This class has no encoder or audio writer. */
public final class Mp3GainAnalyzer {
    public interface Progress {void update(int percent);}
    public static final class Result {
        public final Mp3GainEngine.Info info;
        public final double gainAt89,peak;
        public final boolean peakLimited;
        public final long[] histogram;
        Result(Mp3GainEngine.Info i,ReplayGainAnalysis a,boolean limited) throws IOException {
            info=i;gainAt89=a.gain();peak=a.peak();peakLimited=limited;histogram=a.histogram();
        }
        public double loudness(){return 89-gainAt89;}
        public boolean mayClip(int steps){return Mp3GainEngine.clipping(peak,steps)||(peakLimited&&peak>=0.999&&steps>=0);}
    }
    public static Result analyze(File file,Progress progress) throws IOException {
        Mp3GainEngine.Info info=Mp3GainEngine.inspect(file);
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;
        try{
            extractor.setDataSource(file.getAbsolutePath());int selected=-1;MediaFormat input=null;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat f=extractor.getTrackFormat(i);if("audio/mpeg".equals(f.getString(MediaFormat.KEY_MIME))){selected=i;input=f;break;}}
            if(selected<0)throw new IOException("MP3の音声をデコードできませんでした。");extractor.selectTrack(selected);
            input.setInteger(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_FLOAT);
            decoder=MediaCodec.createDecoderByType("audio/mpeg");
            try{decoder.configure(input,null,null,0);}catch(RuntimeException unsupported){decoder.release();decoder=null;input.setInteger(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_16BIT);decoder=MediaCodec.createDecoderByType("audio/mpeg");decoder.configure(input,null,null,0);}
            decoder.start();ReplayGainAnalysis analysis=new ReplayGainAnalysis(info.sampleRate);
            MediaCodec.BufferInfo buffer=new MediaCodec.BufferInfo();boolean inputEnd=false,outputEnd=false,limited=false;
            int encoding=AudioFormat.ENCODING_PCM_16BIT,channels=info.channels,lastPercent=-1;
            long duration=input.containsKey(MediaFormat.KEY_DURATION)?input.getLong(MediaFormat.KEY_DURATION):0;
            long lastProgress=System.nanoTime();
            while(!outputEnd){
                if(Thread.currentThread().isInterrupted())throw new IOException("音量解析を中断しました。");
                if(!inputEnd){int index=decoder.dequeueInputBuffer(10000);if(index>=0){ByteBuffer data=decoder.getInputBuffer(index);if(data==null)throw new IOException("デコーダーの入力を取得できません。");data.clear();int n=extractor.readSampleData(data,0);
                    if(n<0){decoder.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnd=true;}
                    else{long time=extractor.getSampleTime();decoder.queueInputBuffer(index,0,n,time,0);extractor.advance();}lastProgress=System.nanoTime();}}
                int index=decoder.dequeueOutputBuffer(buffer,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat output=decoder.getOutputFormat();channels=output.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if(channels!=info.channels||output.getInteger(MediaFormat.KEY_SAMPLE_RATE)!=info.sampleRate)throw new IOException("音量解析中に音声形式が変わりました。");
                    encoding=output.containsKey(MediaFormat.KEY_PCM_ENCODING)?output.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    if(encoding!=AudioFormat.ENCODING_PCM_FLOAT&&encoding!=AudioFormat.ENCODING_PCM_16BIT)throw new IOException("このPCM形式の音量解析には対応していません。");limited|=encoding!=AudioFormat.ENCODING_PCM_FLOAT;
                    lastProgress=System.nanoTime();
                }else if(index>=0){try{if(buffer.size>0&&(buffer.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){ByteBuffer data=decoder.getOutputBuffer(index);if(data==null)throw new IOException("解析する音声を取得できません。");data.order(ByteOrder.nativeOrder());data.limit(buffer.offset+buffer.size);data.position(buffer.offset);
                    limited|=encoding!=AudioFormat.ENCODING_PCM_FLOAT;int bytes=encoding==AudioFormat.ENCODING_PCM_FLOAT?4:2;if(buffer.size%(bytes*channels)!=0)throw new IOException("デコードした音声の長さが正しくありません。");
                    while(data.remaining()>=bytes*channels){double left=encoding==AudioFormat.ENCODING_PCM_FLOAT?data.getFloat():data.getShort()/32768.0;double right=channels==1?left:encoding==AudioFormat.ENCODING_PCM_FLOAT?data.getFloat():data.getShort()/32768.0;analysis.add(left,right);}
                    int percent=duration>0?(int)Math.min(99,Math.max(0,buffer.presentationTimeUs*100/duration)):0;if(percent!=lastPercent){lastPercent=percent;if(progress!=null)progress.update(percent);}}
                    outputEnd=(buffer.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                }finally{decoder.releaseOutputBuffer(index,false);}lastProgress=System.nanoTime();}
                if(System.nanoTime()-lastProgress>30_000_000_000L)throw new IOException("音量解析のデコーダーが応答しませんでした。");
            }
            if(progress!=null)progress.update(100);return new Result(info,analysis,limited);
        }catch(IOException e){throw e;}catch(RuntimeException e){throw new IOException("この端末ではMP3の音量解析を完了できませんでした。",e);}
        finally{if(decoder!=null){try{decoder.stop();}catch(RuntimeException ignored){}decoder.release();}extractor.release();}
    }
    private Mp3GainAnalyzer(){}
}
