#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
sdk_root="${ANDROID_SDK_ROOT:?ANDROID_SDK_ROOTを設定してください}"
build_tools="$sdk_root/build-tools/35.0.0"
android_jar="$sdk_root/platforms/android-35/android.jar"
build_dir="$project_dir/build"
dist_dir="$project_dir/dist"
keystore="$project_dir/signing/dentag.keystore"
rm -rf "$build_dir/classes" "$build_dir/dex" "$build_dir/generated"
mkdir -p "$build_dir/compiled" "$build_dir/generated" "$build_dir/classes" "$build_dir/dex" "$dist_dir" "$project_dir/signing"
"$build_tools/aapt2" compile --dir "$project_dir/res" -o "$build_dir/compiled/resources.zip"
"$build_tools/aapt2" link -o "$build_dir/unsigned.apk" -I "$android_jar" --manifest "$project_dir/AndroidManifest.xml" --java "$build_dir/generated" -A "$project_dir/assets" --auto-add-overlay "$build_dir/compiled/resources.zip"
find "$project_dir/src" "$build_dir/generated" -name '*.java' -print0 > "$build_dir/sources.bin"
if command -v javac >/dev/null 2>&1; then
  xargs -0 javac -source 8 -target 8 -encoding UTF-8 -classpath "$android_jar" -d "$build_dir/classes" < "$build_dir/sources.bin"
else
  xargs -0 java -jar "${ECJ_JAR:?ECJ_JARを設定してください}" -source 8 -target 8 -encoding UTF-8 -classpath "$android_jar" -d "$build_dir/classes" < "$build_dir/sources.bin"
fi
(cd "$build_dir/classes" && zip -q -r "$build_dir/classes.jar" .)
"$build_tools/d8" --lib "$android_jar" --min-api 26 --output "$build_dir/dex" "$build_dir/classes.jar"
cp "$build_dir/unsigned.apk" "$build_dir/with-dex.apk"
(cd "$build_dir/dex" && zip -q -u "$build_dir/with-dex.apk" classes.dex)
"$build_tools/zipalign" -f -p 4 "$build_dir/with-dex.apk" "$build_dir/aligned.apk"
if [[ ! -f "$keystore" ]]; then
  keytool -genkeypair -noprompt -keystore "$keystore" -storepass dentag-local-build -keypass dentag-local-build -alias dentag -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=DenTag, OU=Personal, O=Dengaku, C=JP'
fi
"$build_tools/apksigner" sign --ks "$keystore" --ks-pass pass:dentag-local-build --key-pass pass:dentag-local-build --out "$dist_dir/DenTag-v1.1.0.apk" "$build_dir/aligned.apk"
"$build_tools/apksigner" verify --verbose "$dist_dir/DenTag-v1.1.0.apk"
