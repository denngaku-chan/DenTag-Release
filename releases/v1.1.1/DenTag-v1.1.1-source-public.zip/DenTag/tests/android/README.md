# Android画面と保存の回帰テスト

JDK 17以上、Maven 3.9以上、Android SDK Platform 35・Build Tools 35.0.0を用意してください。
`ANDROID_SDK_ROOT` を設定し、プロジェクトのルートで実行します。

```sh
bash build-apk.sh
mvn -f tests/android/pom.xml test
```

RobolectricでAndroid API 26と35を模擬し、各11ケースを実行します。曲カードの操作、保存中の画面再生成、連続した再生成、状態保存直後の完了、再開時の結果反映、続けて上書き保存、保存失敗時の編集維持、コピー保存、元データの取り出しを確認します。エミュレーターは不要です。

`tone.mp3` はテスト用にFFmpegで生成した短い997 Hzの正弦波です。保存先はContentResolverに登録したローカルストリームで模擬しています。端末固有のSAFプロバイダーやMediaCodecの実機検証は含みません。

プロキシが必要な環境では、Mavenのsettings.xmlにプロキシを指定し、Robolectricの依存取得にも `-Dhttps.proxyHost=... -Dhttps.proxyPort=...` を指定してください。
