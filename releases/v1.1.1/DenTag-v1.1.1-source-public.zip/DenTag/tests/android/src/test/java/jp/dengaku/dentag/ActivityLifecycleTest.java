package jp.dengaku.dentag;

import android.app.AlertDialog;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk={26,35})
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.LEGACY)
public class ActivityLifecycleTest {
    private ActivityController<MainActivity> controller;
    private MainActivity activity;

    @Before public void create(){controller=Robolectric.buildActivity(MainActivity.class).setup();activity=controller.get();}
    @After public void destroy(){if(!activity.isDestroyed())controller.pause().stop().destroy();}
    private void invoke(String name,Class<?>[] types,Object... args) throws Exception {Method m=MainActivity.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(activity,args);}
    private View picker(){return ReflectionHelpers.getField(activity,"songPicker");}

    @Test public void emptySongCardOpensPicker(){
        assertTrue(picker().isEnabled());
        picker().performClick();
        assertEquals(Intent.ACTION_OPEN_DOCUMENT,shadowOf(activity).getNextStartedActivityForResult().intent.getAction());
    }
    @Test public void busySongCardCannotStartAnotherPicker() throws Exception {
        invoke("setBusy",new Class<?>[]{boolean.class,String.class},true,"busy");
        assertFalse(picker().isEnabled());picker().performClick();
        assertNull(shadowOf(activity).getNextStartedActivityForResult());
    }
    @Test public void dirtySongCardPreservesCancelConfirmation(){
        ReflectionHelpers.setField(activity,"song",new TagEngine.Song());
        ReflectionHelpers.setField(activity,"dirty",true);
        picker().performClick();
        AlertDialog dialog=ShadowAlertDialog.getLatestAlertDialog();
        assertNotNull(dialog);assertTrue(dialog.isShowing());
        assertNull(shadowOf(activity).getNextStartedActivityForResult());
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
        assertNull(shadowOf(activity).getNextStartedActivityForResult());
    }

    static final class QueuedExecutor extends AbstractExecutorService {
        private final Queue<Runnable> tasks=new ArrayDeque<>();private boolean shutdown;
        public void execute(Runnable r){if(shutdown)throw new RejectedExecutionException();tasks.add(r);}
        public void shutdown(){shutdown=true;}
        public List<Runnable> shutdownNow(){shutdown=true;List<Runnable> out=new ArrayList<>(tasks);tasks.clear();return out;}
        public boolean isShutdown(){return shutdown;}
        public boolean isTerminated(){return shutdown&&tasks.isEmpty();}
        public boolean awaitTermination(long time,TimeUnit unit){return isTerminated();}
        void runPending() throws Exception {Runnable r=tasks.remove();Thread t=new Thread(r,"review-save-worker");t.start();t.join(10000);assertFalse("Save worker did not complete",t.isAlive());}
    }
    public static final class FileProvider extends ContentProvider {
        final File file;
        FileProvider(File file){this.file=file;}
        public boolean onCreate(){return true;}
        public String getType(Uri uri){return "audio/mpeg";}
        public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){MatrixCursor c=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME});c.addRow(new Object[]{"tone.mp3"});return c;}
        public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
        public int update(Uri uri,ContentValues values,String s,String[] a){throw new UnsupportedOperationException();}
        public int delete(Uri uri,String s,String[] a){throw new UnsupportedOperationException();}
        @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {return ParcelFileDescriptor.open(file,mode.contains("w")?ParcelFileDescriptor.MODE_WRITE_ONLY|ParcelFileDescriptor.MODE_TRUNCATE:ParcelFileDescriptor.MODE_READ_ONLY);}
    }
    private File saveTarget;
    private Uri documentUri;
    private byte[] originalBytes;
    private QueuedExecutor replaceWorker(){
        ExecutorService previous=ReflectionHelpers.getField(activity,"worker");previous.shutdown();
        QueuedExecutor executor=new QueuedExecutor();ReflectionHelpers.setField(activity,"worker",executor);return executor;
    }
    private void registerTarget(Uri uri,File target){
        FileProvider provider=new FileProvider(target);provider.attachInfo(activity,new android.content.pm.ProviderInfo());
        ShadowContentResolver.registerProviderInternal(uri.getAuthority(),provider);
        for(ContentResolver contentResolver:new ContentResolver[]{activity.getContentResolver(),activity.getApplicationContext().getContentResolver()}){
            ShadowContentResolver resolver=shadowOf(contentResolver);
            resolver.registerInputStreamSupplier(uri,()->{try{return new FileInputStream(target);}catch(IOException e){throw new UncheckedIOException(e);}});
            resolver.registerOutputStreamSupplier(uri,()->{try{return new FileOutputStream(target);}catch(IOException e){throw new UncheckedIOException(e);}});
        }
    }
    private QueuedExecutor queueSave() throws Exception {
        return queueSave(true);
    }
    private QueuedExecutor queueSave(boolean overwrite) throws Exception {
        File opened=new File(activity.getCacheDir(),"review-opened.mp3");
        File target=new File(activity.getFilesDir(),"review-document.mp3");
        saveTarget=target;
        byte[] bytes=Files.readAllBytes(new File(ActivityLifecycleTest.class.getResource("/tone.mp3").toURI()).toPath());
        originalBytes=bytes;
        Files.write(opened.toPath(),bytes);Files.write(target.toPath(),bytes);
        Uri uri=Uri.parse("content://review/document/tone");
        documentUri=uri;registerTarget(uri,target);
        ReflectionHelpers.setField(activity,"source",opened);
        ReflectionHelpers.setField(activity,"song",TagEngine.read(opened));
        ReflectionHelpers.setField(activity,"displayName","tone.mp3");
        Uri sourceUri=overwrite?uri:Uri.parse("content://review/document/original");
        if(!overwrite){File original=new File(activity.getFilesDir(),"original.mp3");Files.write(original.toPath(),bytes);registerTarget(sourceUri,original);}
        ReflectionHelpers.setField(activity,"sourceUri",sourceUri);
        ReflectionHelpers.setField(activity,"sourceWritable",true);
        invoke("fill",new Class<?>[0]);
        EditText[] fields=ReflectionHelpers.getField(activity,"fields");fields[0].setText("Edited title");
        QueuedExecutor executor=replaceWorker();
        invoke("export",new Class<?>[]{Uri.class,boolean.class},uri,overwrite);
        return executor;
    }
    @Test public void destroyedActivityMustNotShowSaveDialog() throws Exception {
        QueuedExecutor executor=queueSave();
        controller.pause().stop().destroy();assertTrue(activity.isDestroyed());
        executor.runPending();
        shadowOf(Looper.getMainLooper()).idle();
        TextView status=ReflectionHelpers.getField(activity,"status");
        assertEquals("Save status: "+status.getText(),"Edited title",TagEngine.read(saveTarget).values[0]);
        assertNull("A save callback must not create a dialog for a destroyed Activity",ShadowAlertDialog.getLatestAlertDialog());
    }
    @Test public void recreatedEditorMustKeepItsWorkingFileWhenOldSaveCompletes() throws Exception {
        QueuedExecutor executor=queueSave();
        MainActivity old=activity;controller.recreate();activity=controller.get();assertTrue(old.isDestroyed());
        assertTrue(ReflectionHelpers.<Boolean>getField(activity,"busy"));assertFalse(picker().isEnabled());
        executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertEquals("Edited title",TagEngine.read(saveTarget).values[0]);
        File liveSource=ReflectionHelpers.getField(activity,"source");
        assertTrue("Recreated editor must have a readable working file",liveSource.isFile());
        assertArrayEquals(Files.readAllBytes(saveTarget.toPath()),Files.readAllBytes(liveSource.toPath()));
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"dirty"));
        // A second overwrite proves that the editor adopted the saved version, rather than a stale cache file.
        EditText[] fields=ReflectionHelpers.getField(activity,"fields");fields[0].setText("Second save");
        QueuedExecutor next=replaceWorker();invoke("export",new Class<?>[]{Uri.class,boolean.class},documentUri,true);
        next.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertEquals("Second save",TagEngine.read(saveTarget).values[0]);
    }
    @Test public void completionBetweenStateSaveAndRecreationIsDeliveredToNewScreen() throws Exception {
        QueuedExecutor executor=queueSave();File original=ReflectionHelpers.getField(activity,"source");
        Bundle state=new Bundle();controller.saveInstanceState(state);
        executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertTrue("Saved state still references this working file",original.isFile());
        assertNull(ShadowAlertDialog.getLatestAlertDialog());
        Object retained=activity.onRetainNonConfigurationInstance();controller.pause().stop().destroy();
        controller=Robolectric.buildActivity(MainActivity.class);activity=controller.get();
        shadowOf(activity).setLastNonConfigurationInstance(retained);controller.setup(state);
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertEquals("Edited title",ReflectionHelpers.<EditText[]>getField(activity,"fields")[0].getText().toString());
        assertEquals("Edited title",TagEngine.read(ReflectionHelpers.<File>getField(activity,"source")).values[0]);
    }
    @Test public void repeatedRecreationRetainsOnlyOneSave() throws Exception {
        QueuedExecutor executor=queueSave();controller.recreate().recreate();activity=controller.get();
        executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertEquals("Edited title",TagEngine.read(ReflectionHelpers.<File>getField(activity,"source")).values[0]);
        assertEquals("Edited title",TagEngine.read(saveTarget).values[0]);
    }
    @Test public void saveFailureAfterRecreationKeepsEditsAndOriginalWorkingFile() throws Exception {
        QueuedExecutor executor=queueSave();
        byte[] external=Arrays.copyOf(originalBytes,originalBytes.length+1);external[external.length-1]=42;
        Files.write(saveTarget.toPath(),external);
        controller.recreate();activity=controller.get();executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertArrayEquals(external,Files.readAllBytes(saveTarget.toPath()));
        assertTrue(ReflectionHelpers.<File>getField(activity,"source").isFile());
        assertTrue(ReflectionHelpers.<Boolean>getField(activity,"dirty"));assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertEquals("Edited title",ReflectionHelpers.<EditText[]>getField(activity,"fields")[0].getText().toString());
    }
    @Test public void recoverySurvivesRecreationAndWritesOriginalBytes() throws Exception {
        byte[] bytes=Files.readAllBytes(new File(ActivityLifecycleTest.class.getResource("/tone.mp3").toURI()).toPath());
        File backup=new File(activity.getFilesDir(),"overwrite-original.bin");Files.write(backup.toPath(),bytes);
        File target=new File(activity.getFilesDir(),"recovered.mp3");Files.write(target.toPath(),new byte[0]);
        Uri uri=Uri.parse("content://review/document/recovered");registerTarget(uri,target);
        QueuedExecutor executor=replaceWorker();invoke("recover",new Class<?>[]{Uri.class},uri);
        controller.recreate();activity=controller.get();executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertArrayEquals(bytes,Files.readAllBytes(target.toPath()));assertFalse(backup.exists());
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertNotNull(ShadowAlertDialog.getLatestAlertDialog());
    }
    @Test public void copySaveSurvivesRecreationAndPreservesWorkingAudio() throws Exception {
        QueuedExecutor executor=queueSave(false);File original=ReflectionHelpers.getField(activity,"source");
        controller.recreate();activity=controller.get();executor.runPending();shadowOf(Looper.getMainLooper()).idle();
        assertEquals("Edited title",TagEngine.read(saveTarget).values[0]);
        assertArrayEquals(originalBytes,Files.readAllBytes(original.toPath()));
        assertEquals(original,ReflectionHelpers.<File>getField(activity,"source"));
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"dirty"));
    }
    @Test public void completionWhileBackgroundedWaitsUntilResume() throws Exception {
        QueuedExecutor executor=queueSave();controller.pause().stop();
        executor.runPending();shadowOf(Looper.getMainLooper()).idle();assertNull(ShadowAlertDialog.getLatestAlertDialog());
        controller.restart().start().resume();
        assertFalse(ReflectionHelpers.<Boolean>getField(activity,"busy"));
        assertEquals("Edited title",TagEngine.read(ReflectionHelpers.<File>getField(activity,"source")).values[0]);
        assertNotNull(ShadowAlertDialog.getLatestAlertDialog());
    }
}
