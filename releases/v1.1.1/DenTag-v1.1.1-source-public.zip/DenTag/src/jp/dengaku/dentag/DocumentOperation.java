package jp.dengaku.dentag;

import android.content.Context;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import java.io.*;
import java.lang.ref.WeakReference;

/** A document transaction survives configuration changes without retaining an Activity. */
final class DocumentOperation implements Runnable {
    interface Listener { void documentFinished(DocumentOperation operation); }
    static final class Editor {
        final File source;final TagEngine.Song song;final TagEngine.Picture picture;
        final String name,gain,frameHash;final Uri uri;final String[] values;
        final boolean writable,artChanged,gainChanged,dirty,frameUndo;final int frameSteps;
        Editor(File source,TagEngine.Song song,TagEngine.Picture picture,String name,Uri uri,boolean writable,
               String[] values,String gain,boolean artChanged,boolean gainChanged,boolean dirty,int frameSteps,boolean frameUndo,String frameHash){
            this.source=source;this.song=song;this.picture=picture;this.name=name;this.uri=uri;this.writable=writable;
            this.values=values.clone();this.gain=gain;this.artChanged=artChanged;this.gainChanged=gainChanged;this.dirty=dirty;
            this.frameSteps=frameSteps;this.frameUndo=frameUndo;this.frameHash=frameHash;
        }
    }
    static final class Result {
        File source;TagEngine.Song song;String name;Exception error;
    }
    final Editor editor;final boolean overwrite,recovery,editFrames;
    private final ContentResolver resolver;private final File cache,backup,backupName;private final Uri destination;
    private final Handler main=new Handler(Looper.getMainLooper());
    // Listener and result are accessed only on the main thread.
    private WeakReference<Listener> listener=new WeakReference<>(null);private Result result;
    DocumentOperation(Context context,Uri destination,boolean overwrite,boolean recovery,Editor editor){
        Context app=context.getApplicationContext();resolver=app.getContentResolver();cache=app.getCacheDir();
        backup=new File(app.getFilesDir(),"overwrite-original.bin");backupName=new File(app.getFilesDir(),"overwrite-original-name.txt");
        this.destination=destination;this.overwrite=overwrite;this.recovery=recovery;this.editor=editor;
        editFrames=editor.frameSteps!=0||editor.frameUndo;
    }
    String progress(){return recovery?"元データを保存しています…":overwrite?"上書き保存し、音声データを確認しています…":"コピーを保存し、音声データを確認しています…";}
    void attach(Listener owner){listener=new WeakReference<>(owner);deliver();}
    void detach(Listener owner){if(listener.get()==owner)listener.clear();}
    Result result(){return result;}
    private void deliver(){Listener owner=listener.get();if(owner!=null&&result!=null)owner.documentFinished(this);}
    private SaveEngine.Target target(){return new SaveEngine.Target(){
        public InputStream openRead() throws IOException{return resolver.openInputStream(destination);}
        public OutputStream openWrite() throws IOException{return resolver.openOutputStream(destination,"wt");}
    };}
    private String name(){try(Cursor c=resolver.query(destination,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
        if(c!=null&&c.moveToFirst())return c.getString(0);
    }catch(Exception ignored){}return "曲";}
    @Override public void run(){
        Result outcome=new Result();File edited=null,check=null,gained=null;boolean committed=false;
        try{
            if(recovery){
                check=File.createTempFile("recover-",".bin",cache);SaveEngine.copyVerified(backup,target(),check);
                backup.delete();backupName.delete();
            }else{
                String[] values=editor.values.clone();for(int i=0;i<values.length;i++)values[i]=values[i].trim();
                edited=File.createTempFile("edited-",".bin",cache);
                if(editFrames){
                    if(editor.frameHash==null||!editor.frameHash.equals(Mp3GainEngine.inspect(editor.source).audioHash))throw new IOException("解析した音声と一致しません。MP3Gainを設定し直してください。");
                    gained=File.createTempFile("mp3gain-",".mp3",cache);Mp3GainEngine.Prepared prepared=Mp3GainEngine.prepare(editor.source,gained,editor.frameSteps,editor.frameUndo);
                    TagEngine.write(gained,edited,TagEngine.read(gained),values,editor.picture,editor.artChanged,editor.gain,editor.gainChanged,prepared.undo,true);
                    Mp3GainEngine.verifyTransform(editor.source,edited,prepared.appliedSteps);
                }else TagEngine.write(editor.source,edited,editor.song,values,editor.picture,editor.artChanged,editor.gain,editor.gainChanged);
                TagEngine.Song updated=overwrite?TagEngine.read(edited):null;
                check=File.createTempFile("check-",".bin",cache);
                if(overwrite){
                    if(backup.exists())throw new IOException("保管中の元データを先に取り出してください。");
                    try(FileOutputStream out=new FileOutputStream(backupName)){out.write(editor.name.getBytes("UTF-8"));out.getFD().sync();}
                    SaveEngine.overwrite(editor.source,edited,target(),backup,check);
                    committed=true;backupName.delete();outcome.source=edited;outcome.song=updated;
                }else SaveEngine.copyVerified(edited,target(),check);
            }
            outcome.name=name();
        }catch(Exception e){
            if(!overwrite){try{DocumentsContract.deleteDocument(resolver,destination);}catch(Exception ignored){}}
            if(overwrite&&!backup.exists())backupName.delete();outcome.error=e;
        }finally{
            if(edited!=null&&!(overwrite&&committed))edited.delete();if(check!=null)check.delete();if(gained!=null)gained.delete();
        }
        main.post(()->{result=outcome;deliver();});
    }
}
